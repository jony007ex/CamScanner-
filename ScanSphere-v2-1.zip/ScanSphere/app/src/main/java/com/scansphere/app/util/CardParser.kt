package com.scansphere.app.util

import com.scansphere.app.data.ContactData

data class CardLine(val text: String, val height: Int)

/** Rule-based parser that turns visiting card text into contact fields. */
object CardParser {

    private val EMAIL = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val WEB = Regex(
        "(?i)(https?://)?(www\\.)?[a-z0-9-]+(\\.[a-z0-9-]+)*\\." +
            "(com|net|org|info|biz|io|ai|app|tech|xyz|edu|gov|bd|in|uk|us)(\\.[a-z]{2})?(/\\S*)?"
    )
    private val PHONE = Regex("\\+?\\(?\\d[\\d\\s().\\-/]{5,}\\d")
    private val BD_MOBILE = Regex("^(?:880|0)?1[3-9]\\d{8}$")
    private val SPLIT = Regex("[^a-z0-9&]+")

    private val TITLE_WORDS = setOf(
        "ceo", "cto", "cfo", "coo", "md", "avp", "vp", "svp", "evp", "gm", "agm", "dgm",
        "manager", "director", "officer", "engineer", "executive", "president", "head", "lead",
        "assistant", "consultant", "developer", "designer", "chairman", "founder", "specialist",
        "analyst", "coordinator", "supervisor", "advisor", "architect", "partner", "accountant",
        "secretary", "representative", "associate", "professor", "lecturer", "proprietor", "owner",
    )
    private val COMPANY_WORDS = setOf(
        "ltd", "limited", "inc", "corp", "corporation", "company", "bank", "group", "industries",
        "solutions", "technologies", "technology", "plc", "llc", "enterprise", "enterprises",
        "foundation", "university", "consultancy", "consulting", "services", "systems",
        "international", "pharmaceuticals", "pharma", "textiles", "garments", "agency", "trading",
        "holdings", "insurance", "finance", "hospital", "clinic", "school", "college", "institute",
    )
    private val ADDRESS_WORDS = setOf(
        "road", "rd", "street", "house", "floor", "avenue", "lane", "sector", "block", "tower",
        "building", "plaza", "suite", "level", "dhaka", "chittagong", "chattogram", "sylhet",
        "khulna", "rajshahi", "barishal", "rangpur", "gulshan", "banani", "dhanmondi", "motijheel",
        "uttara", "mirpur", "tejgaon", "mohakhali", "bashundhara", "bangladesh", "po", "box",
    )

    private fun words(s: String) = s.lowercase().split(SPLIT).filter { it.isNotEmpty() }

    fun parse(lines: List<CardLine>): ContactData {
        var email = ""
        var website = ""
        val phones = mutableListOf<String>()
        val used = BooleanArray(lines.size)

        lines.forEachIndexed { i, line ->
            val text = line.text
            val m = EMAIL.find(text)
            if (m != null) {
                if (email.isEmpty()) email = m.value
                used[i] = true
            }
            val rest = EMAIL.replace(text, " ")
            val isFax = text.contains("fax", ignoreCase = true)
            PHONE.findAll(rest).forEach { p ->
                val digits = p.value.count { it.isDigit() }
                if (digits in 7..15) {
                    if (!isFax) phones += p.value.trim().replace(Regex("\\s+"), " ")
                    used[i] = true
                }
            }
            if (website.isEmpty()) {
                val w = WEB.find(rest)
                if (w != null && w.value.any { it.isLetter() }) {
                    website = w.value
                    used[i] = true
                }
            }
        }

        val unique = phones.distinct()
        val mobile = unique.firstOrNull { BD_MOBILE.matches(it.filter { ch -> ch.isDigit() }) } ?: unique.firstOrNull() ?: ""
        val phone2 = unique.firstOrNull { it != mobile } ?: ""

        var title = ""
        var company = ""
        val address = mutableListOf<String>()
        val others = mutableListOf<CardLine>()

        lines.forEachIndexed { i, line ->
            if (used[i]) return@forEachIndexed
            val text = line.text
            val w = words(text)
            if (title.isEmpty() && w.any { it in TITLE_WORDS }) {
                title = text
            } else if (company.isEmpty() && w.any { it in COMPANY_WORDS }) {
                company = text
            } else if (w.any { it in ADDRESS_WORDS } || (text.any { it.isDigit() } && text.contains(','))) {
                address += text
            } else if (text.length >= 3) {
                others += line
            }
        }

        fun looksLikeName(s: String): Boolean {
            val count = s.trim().split(Regex("\\s+")).size
            return s.length in 3..40 && count in 1..5 &&
                s.all { it.isLetter() || it == ' ' || it == '.' || it == '-' || it == '\'' }
        }

        val nameLine = others.filter { looksLikeName(it.text) }.maxByOrNull { it.height }
        val rest = others.filter { it !== nameLine }.toMutableList()
        if (company.isEmpty()) {
            val c = rest.filter { l -> l.text.none { it.isDigit() } }.maxByOrNull { it.height }
            if (c != null) {
                company = c.text
                rest.remove(c)
            }
        }

        return ContactData(
            name = nameLine?.text ?: "",
            title = title,
            company = company,
            mobile = mobile,
            phone2 = phone2,
            email = email,
            website = website,
            address = address.joinToString(", "),
            notes = rest.joinToString("\n") { it.text },
        )
    }
}
