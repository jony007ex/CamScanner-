@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.scansphere.app.data.ContactData
import com.scansphere.app.data.QrKind
import com.scansphere.app.data.QrResult
import com.scansphere.app.util.ContactSaver
import com.scansphere.app.util.FileActions
import com.scansphere.app.util.ImageOps
import com.scansphere.app.util.tr
import java.io.File
import java.io.FileOutputStream

// ======================= SIGNATURE =======================

@Composable
fun SignatureScreen(c: AppController, docId: String, page: Int) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val savedFile = File(c.context.filesDir, "signature.png")
    val ink = Color(0xFF0D3B9E)

    fun applySig(sigFile: File) {
        val doc = c.doc(docId) ?: return
        c.work(tr("Adding signature...", "স্বাক্ষর যোগ হচ্ছে...")) {
            c.io {
                val sig = android.graphics.BitmapFactory.decodeFile(sigFile.path)
                    ?: throw IllegalStateException("signature")
                c.repo.transformPages(doc, listOf(page)) { ImageOps.overlaySignature(it, sig) }
            }
            c.refresh()
            c.pop()
            c.toast(tr("Signature added to page ${page + 1}", "${page + 1} নম্বর পেজে স্বাক্ষর যোগ হয়েছে"))
        }
    }

    fun saveDrawing(): Boolean {
        val all = strokes.toList() + listOf(current)
        val points = all.flatten()
        if (points.size < 2 || size.width == 0) return false
        val bmp = android.graphics.Bitmap.createBitmap(size.width, size.height, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(13, 59, 158)
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = 7f
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        all.filter { it.size > 1 }.forEach { pts ->
            val path = android.graphics.Path()
            path.moveTo(pts[0].x, pts[0].y)
            pts.drop(1).forEach { path.lineTo(it.x, it.y) }
            canvas.drawPath(path, paint)
        }
        val pad = 12
        val minX = (points.minOf { it.x }.toInt() - pad).coerceAtLeast(0)
        val minY = (points.minOf { it.y }.toInt() - pad).coerceAtLeast(0)
        val maxX = (points.maxOf { it.x }.toInt() + pad).coerceAtMost(size.width)
        val maxY = (points.maxOf { it.y }.toInt() + pad).coerceAtMost(size.height)
        if (maxX - minX < 4 || maxY - minY < 4) return false
        val cropped = android.graphics.Bitmap.createBitmap(bmp, minX, minY, maxX - minX, maxY - minY)
        FileOutputStream(savedFile).use { cropped.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        return true
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            tr("Draw your signature below. It will be placed at the bottom-right of page ${page + 1}.",
                "নিচে আঙুল দিয়ে স্বাক্ষর করুন। এটা ${page + 1} নম্বর পেজের নিচে ডানদিকে বসবে।"),
            style = MaterialTheme.typography.bodyMedium,
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(260.dp)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                .background(Color.White, RoundedCornerShape(12.dp))
                .onSizeChanged { size = it }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { current = listOf(it) },
                        onDragEnd = {
                            strokes.add(current)
                            current = emptyList()
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            current = current + change.position
                        },
                    )
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                (strokes.toList() + listOf(current)).forEach { pts ->
                    if (pts.size > 1) {
                        val p = Path()
                        p.moveTo(pts[0].x, pts[0].y)
                        pts.drop(1).forEach { p.lineTo(it.x, it.y) }
                        drawPath(p, ink, style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                strokes.clear()
                current = emptyList()
            }, modifier = Modifier.weight(1f)) { Text(tr("Clear", "মুছুন")) }
            Button(onClick = {
                if (saveDrawing()) applySig(savedFile) else c.toast(tr("Please draw a signature first", "আগে স্বাক্ষর আঁকুন"))
            }, modifier = Modifier.weight(1f)) { Text(tr("Save & apply", "সেভ ও যোগ করুন")) }
        }
        if (savedFile.exists()) {
            HorizontalDivider()
            Text(tr("Saved signature", "সেভ করা স্বাক্ষর"), style = MaterialTheme.typography.titleSmall)
            FileImage(savedFile, 600, Modifier.fillMaxWidth().height(90.dp).background(Color.White), ContentScale.Fit)
            WideButton(Icons.Filled.Create, tr("Use saved signature", "সেভ করা স্বাক্ষর ব্যবহার করুন")) { applySig(savedFile) }
        }
    }
}

// ======================= TEXT RESULT =======================

@Composable
fun TextResultScreen(c: AppController, title: String, text: String, original: String) {
    var value by remember(text) { mutableStateOf(text) }
    val clipboard = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = { value = it },
            label = { Text(title) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp),
        )
        WideButton(Icons.Filled.ContentCopy, tr("Copy", "কপি"), primary = true) {
            clipboard.setText(AnnotatedString(value))
            c.toast(tr("Copied", "কপি হয়েছে"))
        }
        WideButton(Icons.Filled.Share, tr("Share text", "টেক্সট শেয়ার")) { FileActions.shareText(c.context, value) }
        WideButton(Icons.Filled.Description, tr("Export as Word (.docx)", "Word ফাইল (.docx)")) { c.shareWord(value, c.newName("Text")) }
        WideButton(Icons.Filled.TextSnippet, tr("Export as TXT", "TXT ফাইল")) { c.shareTxt(value, c.newName("Text")) }
        if (original.isEmpty()) {
            WideButton(Icons.Filled.Translate, tr("Translate to Bangla", "বাংলায় অনুবাদ")) { c.translateText(value) }
        } else {
            HorizontalDivider()
            Text(tr("Original text", "মূল লেখা"), style = MaterialTheme.typography.titleSmall)
            SelectionContainer { Text(original, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

// ======================= CARD REVIEW =======================

@Composable
fun CardReviewScreen(c: AppController, initial: ContactData, imagePath: String?) {
    var d by remember(initial) { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (imagePath != null) {
            Card(Modifier.fillMaxWidth()) {
                FileImage(File(imagePath), 1200, Modifier.fillMaxWidth().heightIn(max = 220.dp).height(200.dp), ContentScale.Fit)
            }
        }
        Text(
            tr("Check the details and correct anything if needed, then save.", "তথ্যগুলো মিলিয়ে দেখুন, ভুল থাকলে ঠিক করে সেভ করুন।"),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Field(tr("Full name", "পুরো নাম"), d.name, Icons.Filled.Person) { d = d.copy(name = it) }
        Field(tr("Job title", "পদবি"), d.title, Icons.Filled.Work) { d = d.copy(title = it) }
        Field(tr("Company", "প্রতিষ্ঠান"), d.company, Icons.Filled.Business) { d = d.copy(company = it) }
        Field(tr("Mobile", "মোবাইল"), d.mobile, Icons.Filled.PhoneAndroid, KeyboardType.Phone) { d = d.copy(mobile = it) }
        Field(tr("Office phone", "অফিস ফোন"), d.phone2, Icons.Filled.Phone, KeyboardType.Phone) { d = d.copy(phone2 = it) }
        Field(tr("Email", "ইমেইল"), d.email, Icons.Filled.Email, KeyboardType.Email) { d = d.copy(email = it) }
        Field(tr("Website", "ওয়েবসাইট"), d.website, Icons.Filled.Language, KeyboardType.Uri) { d = d.copy(website = it) }
        Field(tr("Address", "ঠিকানা"), d.address, Icons.Filled.LocationOn, single = false) { d = d.copy(address = it) }
        Field(tr("Notes", "নোট"), d.notes, Icons.Filled.Edit, single = false) { d = d.copy(notes = it) }
        WideButton(Icons.Filled.PersonAdd, tr("Save to Contacts", "কন্টাক্টে সেভ করুন"), primary = true) {
            if (d.hasAnyValue()) ContactSaver.save(c.context, d) else c.toast(tr("Nothing to save", "সেভ করার মতো তথ্য নেই"))
        }
        WideButton(Icons.Filled.Share, tr("Share as vCard", "vCard হিসেবে শেয়ার")) { ContactSaver.shareVcard(c.context, d) }
    }
}

@Composable
private fun Field(label: String, value: String, icon: ImageVector, type: KeyboardType = KeyboardType.Text, single: Boolean = true, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, null) },
        singleLine = single,
        maxLines = if (single) 1 else 4,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        modifier = Modifier.fillMaxWidth(),
    )
}

// ======================= QR =======================

private fun QrKind.label(): String = when (this) {
    QrKind.CONTACT -> tr("Contact", "কন্টাক্ট")
    QrKind.URL -> tr("Website link", "ওয়েবসাইট লিংক")
    QrKind.WIFI -> tr("Wi-Fi network", "Wi-Fi নেটওয়ার্ক")
    QrKind.PHONE -> tr("Phone number", "ফোন নম্বর")
    QrKind.EMAIL -> tr("Email", "ইমেইল")
    QrKind.SMS -> "SMS"
    QrKind.TEXT -> tr("Text", "টেক্সট")
    QrKind.OTHER -> tr("Barcode", "বারকোড")
}

private fun QrKind.icon(): ImageVector = when (this) {
    QrKind.CONTACT -> Icons.Filled.ContactPage
    QrKind.URL -> Icons.Filled.Link
    QrKind.WIFI -> Icons.Filled.Wifi
    QrKind.PHONE -> Icons.Filled.Phone
    QrKind.EMAIL -> Icons.Filled.Email
    QrKind.SMS -> Icons.Filled.Sms
    QrKind.TEXT -> Icons.Filled.TextFields
    QrKind.OTHER -> Icons.Filled.QrCode
}

@Composable
fun QrDetailScreen(c: AppController, r: QrResult) {
    val clipboard = LocalClipboardManager.current
    val value = r.display.trim()
    fun copy(t: String) {
        clipboard.setText(AnnotatedString(t))
        c.toast(tr("Copied", "কপি হয়েছে"))
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(r.kind.icon(), null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(r.kind.label(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                val ct = r.contact
                if (r.kind == QrKind.CONTACT && ct != null) {
                    listOf(ct.name, ct.title, ct.company, ct.mobile, ct.phone2, ct.email, ct.website, ct.address)
                        .filter { it.isNotBlank() }
                        .forEach { SelectionContainer { Text(it, style = MaterialTheme.typography.bodyLarge) } }
                } else if (r.kind == QrKind.WIFI) {
                    Text(tr("Network: ", "নেটওয়ার্ক: ") + r.wifiSsid)
                    Text(tr("Password: ", "পাসওয়ার্ড: ") + r.wifiPassword)
                } else {
                    SelectionContainer { Text(value, style = MaterialTheme.typography.bodyLarge) }
                }
            }
        }
        when (r.kind) {
            QrKind.CONTACT -> WideButton(Icons.Filled.PersonAdd, tr("Save to Contacts", "কন্টাক্টে সেভ করুন"), primary = true) {
                c.push(Screen.CardReview(r.contact ?: ContactData(notes = r.raw), null))
            }
            QrKind.URL -> {
                Text(tr("Check the link before opening it.", "খোলার আগে লিংকটা দেখে নিন।"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                WideButton(Icons.Filled.Language, tr("Open link", "লিংক খুলুন"), primary = true) {
                    val url = if (value.startsWith("http://", true) || value.startsWith("https://", true)) value else "https://$value"
                    FileActions.safeStart(c.context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
            QrKind.PHONE -> {
                WideButton(Icons.Filled.Call, tr("Call", "কল করুন"), primary = true) {
                    FileActions.safeStart(c.context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(value))))
                }
                WideButton(Icons.Filled.PersonAdd, tr("Save to Contacts", "কন্টাক্টে সেভ করুন")) { c.push(Screen.CardReview(ContactData(mobile = value), null)) }
            }
            QrKind.EMAIL -> {
                WideButton(Icons.Filled.Email, tr("Send email", "ইমেইল পাঠান"), primary = true) {
                    FileActions.safeStart(c.context, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$value")))
                }
                WideButton(Icons.Filled.PersonAdd, tr("Save to Contacts", "কন্টাক্টে সেভ করুন")) { c.push(Screen.CardReview(ContactData(email = value), null)) }
            }
            QrKind.SMS -> WideButton(Icons.Filled.Sms, tr("Send SMS", "SMS পাঠান"), primary = true) {
                FileActions.safeStart(c.context, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(value))))
            }
            QrKind.WIFI -> {
                if (r.wifiPassword.isNotEmpty()) {
                    WideButton(Icons.Filled.VpnKey, tr("Copy password", "পাসওয়ার্ড কপি"), primary = true) { copy(r.wifiPassword) }
                }
                WideButton(Icons.Filled.Wifi, tr("Open Wi-Fi settings", "Wi-Fi সেটিংস খুলুন")) {
                    FileActions.safeStart(c.context, Intent(Settings.ACTION_WIFI_SETTINGS))
                }
            }
            else -> Unit
        }
        WideButton(Icons.Filled.ContentCopy, tr("Copy", "কপি")) { copy(r.raw.ifBlank { value }) }
        WideButton(Icons.Filled.Share, tr("Share", "শেয়ার")) { FileActions.shareText(c.context, r.raw.ifBlank { value }) }
    }
}

@Composable
fun QrHistoryScreen(c: AppController) {
    if (c.qrHistory.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            EmptyState(Icons.Filled.History, tr("No scan history", "কোনো স্ক্যান হিস্ট্রি নেই"), tr("QR codes you scan will appear here.", "স্ক্যান করা QR কোড এখানে দেখা যাবে।"))
            Button(onClick = { c.scanQr() }) { Text(tr("Scan now", "এখনই স্ক্যান করুন")) }
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { c.scanQr() }) { Icon(Icons.Filled.QrCodeScanner, null); Spacer(Modifier.width(6.dp)); Text(tr("Scan", "স্ক্যান")) }
                TextButton(onClick = { c.clearQrHistory() }) { Icon(Icons.Filled.DeleteSweep, null); Spacer(Modifier.width(6.dp)); Text(tr("Clear", "মুছুন")) }
            }
        }
        items(c.qrHistory, key = { it.time.toString() + it.raw.hashCode() }) { r ->
            ListItem(
                headlineContent = { Text(r.display, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(r.kind.label() + "  •  " + formatDate(r.time)) },
                leadingContent = { Icon(r.kind.icon(), null, tint = MaterialTheme.colorScheme.primary) },
                modifier = Modifier.clickable { c.push(Screen.QrDetail(r)) },
            )
            HorizontalDivider()
        }
    }
}

// ======================= DOC PICKER =======================

@Composable
fun DocPickerScreen(c: AppController, purpose: DocPurpose) {
    var selected by remember { mutableStateOf(listOf<String>()) }
    val multi = purpose == DocPurpose.MERGE
    Column(Modifier.fillMaxSize()) {
        Text(
            if (multi) tr("Select files in the order you want them merged", "যে ক্রমে একত্র করতে চান সেই ক্রমে ফাইল বাছুন")
            else tr("Choose a file", "একটা ফাইল বাছুন"),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(16.dp),
        )
        LazyColumn(Modifier.weight(1f)) {
            items(c.docs.filter { !it.locked }, key = { it.id }) { d ->
                val isSel = d.id in selected
                DocRow(c, d, if (multi) isSel else null, {
                    selected = if (isSel) selected - d.id else selected + d.id
                }) {
                    if (multi) {
                        selected = if (isSel) selected - d.id else selected + d.id
                    } else {
                        c.handlePurpose(purpose, d)
                    }
                }
            }
        }
        if (multi) {
            Surface(tonalElevation = 4.dp) {
                Button(
                    onClick = {
                        val list = selected.mapNotNull { id -> c.doc(id) }
                        if (list.size < 2) {
                            c.toast(tr("Select at least 2 files", "অন্তত ২টা ফাইল বাছুন"))
                        } else {
                            c.pop()
                            c.merge(list)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(12.dp).height(50.dp),
                ) { Text(tr("Merge", "একত্র করুন") + " (" + selected.size + ")") }
            }
        }
    }
}
