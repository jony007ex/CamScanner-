package com.scansphere.app.data

import android.content.Context
import org.json.JSONArray

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("scan_history", Context.MODE_PRIVATE)

    fun all(): List<QrResult> {
        val arr = runCatching { JSONArray(prefs.getString("items", "[]")) }.getOrElse { JSONArray() }
        return (0 until arr.length()).mapNotNull { i ->
            runCatching { QrResult.fromJson(arr.getJSONObject(i)) }.getOrNull()
        }
    }

    fun add(result: QrResult): List<QrResult> {
        val list = (listOf(result) + all()).take(100)
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("items", arr.toString()).apply()
        return list
    }

    fun clear() {
        prefs.edit().remove("items").apply()
    }
}
