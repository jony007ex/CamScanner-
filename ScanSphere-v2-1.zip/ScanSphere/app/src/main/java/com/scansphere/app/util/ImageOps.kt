package com.scansphere.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/** All image processing used by the scanner tools. */
object ImageOps {

    private fun sampleSize(w: Int, h: Int, maxDim: Int): Int {
        var s = 1
        while (w / s > maxDim || h / s > maxDim) s *= 2
        return s
    }

    fun decodeFile(file: File, maxDim: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            if (bounds.outWidth <= 0) return null
            val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim) }
            BitmapFactory.decodeFile(file.path, opts)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    fun decodeUri(context: Context, uri: Uri, maxDim: Int): Bitmap? {
        return try {
            val cr = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return null
            val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim) }
            val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> rotate(bmp, 90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> rotate(bmp, 180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> rotate(bmp, 270f)
                else -> bmp
            }
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    fun saveJpeg(bmp: Bitmap, file: File, quality: Int = 90) {
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    }

    fun rotate(bmp: Bitmap, degrees: Float): Bitmap {
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    // ---------- Filters ----------

    private fun contrastMatrix(contrast: Float, brightness: Float): ColorMatrix {
        val t = (1f - contrast) * 128f + brightness
        return ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, t,
                0f, contrast, 0f, 0f, t,
                0f, 0f, contrast, 0f, t,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    }

    private fun applyMatrix(src: Bitmap, cm: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    fun enhance(src: Bitmap): Bitmap {
        val cm = ColorMatrix().apply { setSaturation(1.15f) }
        cm.postConcat(contrastMatrix(1.25f, 14f))
        return applyMatrix(src, cm)
    }

    fun grayscale(src: Bitmap): Bitmap {
        val cm = ColorMatrix().apply { setSaturation(0f) }
        return applyMatrix(src, cm)
    }

    fun blackWhite(src: Bitmap): Bitmap {
        val cm = ColorMatrix().apply { setSaturation(0f) }
        cm.postConcat(contrastMatrix(2.6f, 45f))
        return applyMatrix(src, cm)
    }

    /** Brightens paper and removes light stains, shadows and pencil marks. */
    fun eraseMarks(src: Bitmap): Bitmap {
        val cm = ColorMatrix().apply { setSaturation(0.85f) }
        cm.postConcat(contrastMatrix(1.8f, 60f))
        return applyMatrix(src, cm)
    }

    // ---------- Overlays ----------

    fun watermark(src: Bitmap, text: String): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(70, 110, 110, 110)
            textSize = out.width / 10f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        canvas.save()
        canvas.rotate(-35f, out.width / 2f, out.height / 2f)
        val step = paint.textSize * 3.2f
        var y = -out.height * 0.4f
        while (y < out.height * 1.4f) {
            canvas.drawText(text, out.width / 2f, y, paint)
            y += step
        }
        canvas.restore()
        return out
    }

    fun stamp(src: Bitmap, text: String): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(200, 30, 30)
            textSize = (out.width / 32f).coerceAtLeast(18f)
            typeface = Typeface.DEFAULT_BOLD
        }
        val w = paint.measureText(text)
        val pad = paint.textSize * 0.4f
        val x = out.width - w - pad * 3
        val y = out.height - pad * 3
        val bg = Paint().apply { color = Color.argb(210, 255, 255, 255) }
        canvas.drawRect(x - pad, y - paint.textSize - pad / 2, x + w + pad, y + pad, bg)
        canvas.drawText(text, x, y - pad / 4, paint)
        return out
    }

    fun overlaySignature(src: Bitmap, sig: Bitmap): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val targetW = out.width * 0.3f
        val targetH = targetW * sig.height / sig.width
        val margin = out.width * 0.05f
        val left = out.width - targetW - margin
        val top = out.height - targetH - margin
        canvas.drawBitmap(sig, null, RectF(left, top, left + targetW, top + targetH), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // ---------- Layouts ----------

    /** Splits a photo of an open book into left and right pages. */
    fun splitBook(src: Bitmap): List<Bitmap> {
        if (src.width <= src.height) return listOf(src)
        val half = src.width / 2
        return listOf(
            Bitmap.createBitmap(src, 0, 0, half, src.height),
            Bitmap.createBitmap(src, half, 0, src.width - half, src.height),
        )
    }

    /** Places front and back of an ID card on one A4 page at real size (150 dpi). */
    fun idCardSheet(cards: List<Bitmap>): Bitmap {
        val sheet = Bitmap.createBitmap(1240, 1754, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheet)
        canvas.drawColor(Color.WHITE)
        val border = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        var y = 220f
        cards.take(2).forEach { raw ->
            val card = if (raw.height > raw.width) rotate(raw, 90f) else raw
            val w = 506f
            val h = w * card.height / card.width
            val x = (sheet.width - w) / 2f
            val rect = RectF(x, y, x + w, y + h)
            canvas.drawBitmap(card, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.drawRect(rect, border)
            y += h + 140f
        }
        return sheet
    }

    /** Makes a 4x6 inch print sheet filled with passport-size photos (300 dpi). */
    fun idPhotoSheet(photo: Bitmap, widthMm: Float, heightMm: Float): Bitmap {
        val pw = (widthMm / 25.4f * 300f).toInt()
        val ph = (heightMm / 25.4f * 300f).toInt()
        val target = pw.toFloat() / ph
        val srcRatio = photo.width.toFloat() / photo.height
        val src = if (srcRatio > target) {
            val w = (photo.height * target).toInt()
            Rect((photo.width - w) / 2, 0, (photo.width - w) / 2 + w, photo.height)
        } else {
            val h = (photo.width / target).toInt()
            Rect(0, (photo.height - h) / 4, photo.width, (photo.height - h) / 4 + h)
        }
        val sheet = Bitmap.createBitmap(1200, 1800, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheet)
        canvas.drawColor(Color.WHITE)
        val gap = 30
        val cols = ((1200 - gap) / (pw + gap)).coerceAtLeast(1)
        val rows = ((1800 - gap) / (ph + gap)).coerceAtLeast(1)
        val startX = (1200 - (cols * pw + (cols - 1) * gap)) / 2
        val startY = (1800 - (rows * ph + (rows - 1) * gap)) / 2
        val border = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val x = startX + c * (pw + gap)
                val y = startY + r * (ph + gap)
                val dst = Rect(x, y, x + pw, y + ph)
                canvas.drawBitmap(photo, src, dst, paint)
                canvas.drawRect(dst, border)
            }
        }
        return sheet
    }

    /** Stitches all pages into one tall image. */
    fun longImage(files: List<File>): Bitmap? {
        val sizes = files.map { f ->
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            Pair(o.outWidth.coerceAtLeast(1), o.outHeight.coerceAtLeast(1))
        }
        if (sizes.isEmpty()) return null
        var width = 1080f
        var total = sizes.sumOf { (width * it.second / it.first).toDouble() }.toFloat()
        val maxHeight = 14000f
        if (total > maxHeight) {
            width = width * maxHeight / total
            total = maxHeight
        }
        val out = Bitmap.createBitmap(width.toInt(), total.toInt().coerceAtLeast(1), Bitmap.Config.RGB_565)
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        var y = 0f
        files.forEachIndexed { i, f ->
            val h = width * sizes[i].second / sizes[i].first
            val bmp = decodeFile(f, 1600)
            if (bmp != null) {
                canvas.drawBitmap(bmp, null, RectF(0f, y, width, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
                bmp.recycle()
            }
            y += h
        }
        return out
    }
}
