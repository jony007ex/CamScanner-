package com.scansphere.app.data

import org.json.JSONArray
import org.json.JSONObject

object Category {
    const val SCAN = "scan"
    const val PDF = "pdf"
    const val ID = "id"
    const val CARD = "card"
    const val PHOTO = "photo"
}

object Tags {
    const val BUSINESS_CARD = "Business Card"
    const val ID_CARD = "ID Card"
    const val NOTE = "Note"
    const val PPT = "PPT"
    const val WHITEBOARD = "Whiteboard"
    const val BOOK = "Book"
    val ALL = listOf(BUSINESS_CARD, ID_CARD, NOTE, PPT, WHITEBOARD, BOOK)
}

/** A scanned document: a folder of JPEG pages plus meta.json. */
data class Doc(
    val id: String,
    val name: String,
    val created: Long,
    val modified: Long,
    val pages: List<String>,
    val category: String,
    val tags: List<String>,
    val folder: String,
    val pinHash: String,
) {
    val locked: Boolean get() = pinHash.isNotEmpty()

    fun toJson(): JSONObject {
        val p = JSONArray()
        pages.forEach { p.put(it) }
        val t = JSONArray()
        tags.forEach { t.put(it) }
        return JSONObject()
            .put("name", name).put("created", created).put("modified", modified)
            .put("pages", p).put("category", category).put("tags", t)
            .put("folder", folder).put("pin", pinHash)
    }

    companion object {
        fun fromJson(id: String, o: JSONObject): Doc {
            val p = o.optJSONArray("pages") ?: JSONArray()
            val t = o.optJSONArray("tags") ?: JSONArray()
            return Doc(
                id = id,
                name = o.optString("name", "Scan"),
                created = o.optLong("created"),
                modified = o.optLong("modified"),
                pages = (0 until p.length()).map { p.getString(it) },
                category = o.optString("category", Category.SCAN),
                tags = (0 until t.length()).map { t.getString(it) },
                folder = o.optString("folder", ""),
                pinHash = o.optString("pin", ""),
            )
        }
    }
}

data class ContactData(
    val name: String = "",
    val title: String = "",
    val company: String = "",
    val mobile: String = "",
    val phone2: String = "",
    val email: String = "",
    val website: String = "",
    val address: String = "",
    val notes: String = "",
) {
    fun hasAnyValue(): Boolean =
        listOf(name, title, company, mobile, phone2, email, website, address).any { it.isNotBlank() }

    fun toJson(): JSONObject = JSONObject()
        .put("name", name).put("title", title).put("company", company)
        .put("mobile", mobile).put("phone2", phone2).put("email", email)
        .put("website", website).put("address", address).put("notes", notes)

    companion object {
        fun fromJson(o: JSONObject) = ContactData(
            name = o.optString("name"), title = o.optString("title"),
            company = o.optString("company"), mobile = o.optString("mobile"),
            phone2 = o.optString("phone2"), email = o.optString("email"),
            website = o.optString("website"), address = o.optString("address"),
            notes = o.optString("notes"),
        )
    }
}

enum class QrKind { CONTACT, URL, WIFI, PHONE, EMAIL, SMS, TEXT, OTHER }

data class QrResult(
    val kind: QrKind,
    val raw: String,
    val display: String,
    val contact: ContactData? = null,
    val wifiSsid: String = "",
    val wifiPassword: String = "",
    val time: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
            .put("kind", kind.name).put("raw", raw).put("display", display)
            .put("ssid", wifiSsid).put("password", wifiPassword).put("time", time)
        if (contact != null) o.put("contact", contact.toJson())
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): QrResult {
            val kind = runCatching { QrKind.valueOf(o.optString("kind")) }.getOrDefault(QrKind.TEXT)
            val cj = o.optJSONObject("contact")
            return QrResult(
                kind = kind,
                raw = o.optString("raw"),
                display = o.optString("display"),
                contact = if (cj != null) ContactData.fromJson(cj) else null,
                wifiSsid = o.optString("ssid"),
                wifiPassword = o.optString("password"),
                time = o.optLong("time", System.currentTimeMillis()),
            )
        }
    }
}
