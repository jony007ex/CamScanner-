package com.scansphere.app.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Simple in-app language switch (Bangla / English). */
object L10n {
    var bangla by mutableStateOf(true)

    fun init(context: Context) {
        bangla = context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("bangla", true)
    }

    fun set(context: Context, value: Boolean) {
        bangla = value
        context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putBoolean("bangla", value).apply()
    }
}

fun tr(en: String, bn: String): String = if (L10n.bangla) bn else en
