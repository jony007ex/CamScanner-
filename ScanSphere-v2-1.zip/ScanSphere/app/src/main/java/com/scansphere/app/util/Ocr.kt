package com.scansphere.app.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}

/** On-device text recognition and translation (Google ML Kit). */
object Ocr {

    suspend fun recognize(bmp: Bitmap): Text {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            return recognizer.process(InputImage.fromBitmap(bmp, 0)).awaitTask()
        } finally {
            recognizer.close()
        }
    }

    suspend fun textOfFiles(files: List<File>): String {
        val parts = mutableListOf<String>()
        for (f in files) {
            val bmp = ImageOps.decodeFile(f, 2400) ?: continue
            parts += recognize(bmp).text
            bmp.recycle()
        }
        return parts.joinToString("\n\n").trim()
    }

    suspend fun textOfUris(context: Context, uris: List<Uri>): String {
        val parts = mutableListOf<String>()
        for (u in uris) {
            val bmp = ImageOps.decodeUri(context, u, 2400) ?: continue
            parts += recognize(bmp).text
            bmp.recycle()
        }
        return parts.joinToString("\n\n").trim()
    }

    suspend fun cardLines(file: File): List<CardLine> {
        val bmp = ImageOps.decodeFile(file, 2400) ?: return emptyList()
        val text = recognize(bmp)
        return text.textBlocks
            .flatMap { it.lines }
            .map { CardLine(it.text.trim(), it.boundingBox?.height() ?: 0) }
            .filter { it.text.isNotEmpty() }
    }

    /** Translates English text to Bangla. Downloads the language model once (about 30 MB). */
    suspend fun translateToBangla(text: String): String {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)
        try {
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).awaitTask()
            val out = mutableListOf<String>()
            for (line in text.split("\n")) {
                out += if (line.isBlank()) line else translator.translate(line).awaitTask()
            }
            return out.joinToString("\n")
        } finally {
            translator.close()
        }
    }
}
