package com.scansphere.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Teal = Color(0xFF19BC9C)

private val Dark = darkColorScheme(
    primary = Teal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF0E5A4B),
    onPrimaryContainer = Color(0xFFC9F5EA),
    secondary = Color(0xFF4A7DFF),
    background = Color(0xFF1E1E20),
    surface = Color(0xFF1E1E20),
    surfaceVariant = Color(0xFF2C2C2F),
    surfaceContainer = Color(0xFF262628),
    surfaceContainerHigh = Color(0xFF2C2C2F),
    onSurface = Color(0xFFF1F1F1),
    onSurfaceVariant = Color(0xFFB4B4B8),
)

private val Light = lightColorScheme(
    primary = Color(0xFF119C80),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC9F5EA),
    onPrimaryContainer = Color(0xFF00382D),
    secondary = Color(0xFF3A6AE8),
    surfaceVariant = Color(0xFFF0F2F4),
)

@Composable
fun ScanSphereTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
