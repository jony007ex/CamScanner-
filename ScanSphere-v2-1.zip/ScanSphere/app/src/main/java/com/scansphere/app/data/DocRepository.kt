package com.scansphere.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import com.scansphere.app.util.ImageOps
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Stores documents as folders of JPEG pages (files/docs/<id>/). */
class DocRepository(private val context: Context) {

    private val root: File
        get() = File(context.filesDir, "docs").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("repo", Context.MODE_PRIVATE)

    private fun dirOf(id: String) = File(root, id)

    fun list(): List<Doc> =
        root.listFiles()?.filter { it.isDirectory }?.mapNotNull { load(it.name) }
            ?.sortedByDescending { it.modified } ?: emptyList()

    fun load(id: String): Doc? = try {
        Doc.fromJson(id, JSONObject(File(dirOf(id), "meta.json").readText()))
    } catch (e: Exception) {
        null
    }

    private fun save(doc: Doc): Doc {
        val d = doc.copy(modified = System.currentTimeMillis())
        File(dirOf(d.id), "meta.json").writeText(d.toJson().toString())
        return d
    }

    fun pageFiles(doc: Doc): List<File> = doc.pages.map { File(dirOf(doc.id), it) }

    fun defaultName(prefix: String): String =
        prefix + " " + SimpleDateFormat("dd-MM-yyyy HH.mm", Locale.US).format(Date())

    private fun newPageName() = "p_" + UUID.randomUUID().toString().take(8) + ".jpg"

    fun newDoc(name: String, category: String, tags: List<String>): Doc {
        val id = "d" + System.currentTimeMillis() + UUID.randomUUID().toString().take(4)
        dirOf(id).mkdirs()
        val now = System.currentTimeMillis()
        return save(Doc(id, name, now, now, emptyList(), category, tags, "", ""))
    }

    /** Creates a document from bitmaps (recycled after saving). */
    fun createFromBitmaps(name: String, category: String, tags: List<String>, bitmaps: List<Bitmap>): Doc {
        var doc = newDoc(name, category, tags)
        val names = mutableListOf<String>()
        bitmaps.forEach { bmp ->
            val n = newPageName()
            ImageOps.saveJpeg(bmp, File(dirOf(doc.id), n))
            names += n
        }
        doc = doc.copy(pages = names)
        return save(doc)
    }

    /** Imports images; [transform] can split or edit each page. */
    fun importUris(
        uris: List<Uri>,
        name: String,
        category: String,
        tags: List<String>,
        transform: (Bitmap) -> List<Bitmap> = { listOf(it) },
    ): Doc {
        val doc = newDoc(name, category, tags)
        return appendUris(doc, uris, transform)
    }

    fun appendUris(doc: Doc, uris: List<Uri>, transform: (Bitmap) -> List<Bitmap> = { listOf(it) }): Doc {
        val names = doc.pages.toMutableList()
        uris.forEach { uri ->
            val bmp = ImageOps.decodeUri(context, uri, 2600) ?: return@forEach
            transform(bmp).forEach { out ->
                val n = newPageName()
                ImageOps.saveJpeg(out, File(dirOf(doc.id), n))
                names += n
            }
        }
        return save(doc.copy(pages = names))
    }

    fun displayName(uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /** Converts every PDF page into a JPEG page. Returns null for protected or broken PDFs. */
    fun importPdf(uri: Uri): Doc? {
        val name = displayName(uri)?.substringBeforeLast('.')?.ifBlank { null } ?: defaultName("PDF")
        return try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return null
            pfd.use { fd ->
                val renderer = PdfRenderer(fd)
                var doc = newDoc(name, Category.PDF, emptyList())
                val names = mutableListOf<String>()
                try {
                    for (i in 0 until renderer.pageCount) {
                        val page = renderer.openPage(i)
                        val scale = 2
                        val bmp = Bitmap.createBitmap(page.width * scale, page.height * scale, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        page.close()
                        val n = newPageName()
                        ImageOps.saveJpeg(bmp, File(dirOf(doc.id), n))
                        bmp.recycle()
                        names += n
                    }
                } finally {
                    renderer.close()
                }
                doc = doc.copy(pages = names)
                save(doc)
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Applies [edit] to the given pages and stores each result under a new file name. */
    fun transformPages(doc: Doc, indices: List<Int>, edit: (Bitmap) -> Bitmap): Doc {
        val names = doc.pages.toMutableList()
        indices.filter { it in names.indices }.forEach { i ->
            val old = File(dirOf(doc.id), names[i])
            val bmp = ImageOps.decodeFile(old, 3000) ?: return@forEach
            val out = edit(bmp)
            val n = newPageName()
            ImageOps.saveJpeg(out, File(dirOf(doc.id), n))
            old.delete()
            names[i] = n
        }
        return save(doc.copy(pages = names))
    }

    fun movePage(doc: Doc, from: Int, to: Int): Doc {
        if (from !in doc.pages.indices || to !in doc.pages.indices) return doc
        val names = doc.pages.toMutableList()
        val item = names.removeAt(from)
        names.add(to, item)
        return save(doc.copy(pages = names))
    }

    fun deletePage(doc: Doc, index: Int): Doc {
        if (index !in doc.pages.indices) return doc
        File(dirOf(doc.id), doc.pages[index]).delete()
        return save(doc.copy(pages = doc.pages.filterIndexed { i, _ -> i != index }))
    }

    fun extractPages(doc: Doc, indices: List<Int>, name: String): Doc {
        val newDoc = newDoc(name, doc.category, doc.tags)
        val names = mutableListOf<String>()
        indices.sorted().filter { it in doc.pages.indices }.forEach { i ->
            val n = newPageName()
            File(dirOf(doc.id), doc.pages[i]).copyTo(File(dirOf(newDoc.id), n), overwrite = true)
            names += n
        }
        return save(newDoc.copy(pages = names))
    }

    fun merge(docs: List<Doc>, name: String): Doc {
        val newDoc = newDoc(name, Category.SCAN, emptyList())
        val names = mutableListOf<String>()
        docs.forEach { d ->
            d.pages.forEach { p ->
                val n = newPageName()
                File(dirOf(d.id), p).copyTo(File(dirOf(newDoc.id), n), overwrite = true)
                names += n
            }
        }
        return save(newDoc.copy(pages = names))
    }

    fun rename(doc: Doc, name: String): Doc = save(doc.copy(name = name.trim().ifBlank { doc.name }))
    fun setTags(doc: Doc, tags: List<String>): Doc = save(doc.copy(tags = tags))
    fun setFolder(doc: Doc, folder: String): Doc = save(doc.copy(folder = folder))
    fun setPin(doc: Doc, pin: String): Doc = save(doc.copy(pinHash = if (pin.isEmpty()) "" else hash(doc.id, pin)))
    fun checkPin(doc: Doc, pin: String): Boolean = hash(doc.id, pin) == doc.pinHash

    private fun hash(id: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest((id + ":" + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun delete(doc: Doc) {
        dirOf(doc.id).deleteRecursively()
    }

    fun folders(): List<String> = (prefs.getStringSet("folders", emptySet()) ?: emptySet()).sorted()

    fun addFolder(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        prefs.edit().putStringSet("folders", (folders() + clean).toSet()).apply()
    }

    fun storageBytes(): Long = root.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun exportDir(): File = File(context.cacheDir, "export").apply { mkdirs() }

    fun safeName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "document" }

    /** Builds a PDF from the page images. */
    fun buildPdf(doc: Doc): File {
        val out = File(exportDir(), safeName(doc.name) + ".pdf")
        val pdf = PdfDocument()
        try {
            pageFiles(doc).forEachIndexed { i, f ->
                val bmp = ImageOps.decodeFile(f, 2000) ?: return@forEachIndexed
                val w = 595
                val h = (595f * bmp.height / bmp.width).toInt().coerceAtLeast(1)
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(w, h, i + 1).create())
                page.canvas.drawBitmap(bmp, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
                pdf.finishPage(page)
                bmp.recycle()
            }
            FileOutputStream(out).use { pdf.writeTo(it) }
        } finally {
            pdf.close()
        }
        return out
    }

    /** Copies the page JPEGs with readable names for sharing. */
    fun exportImages(doc: Doc): List<File> {
        val dir = File(exportDir(), "img_" + doc.id).apply {
            deleteRecursively()
            mkdirs()
        }
        return pageFiles(doc).mapIndexed { i, f ->
            val out = File(dir, safeName(doc.name) + "_" + (i + 1) + ".jpg")
            f.copyTo(out, overwrite = true)
        }
    }
}
