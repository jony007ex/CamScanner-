package com.scansphere.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.scansphere.app.ui.ScanSphereApp
import com.scansphere.app.ui.ScanSphereTheme
import com.scansphere.app.util.L10n

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L10n.init(this)
        setContent {
            ScanSphereTheme {
                ScanSphereApp()
            }
        }
    }
}
