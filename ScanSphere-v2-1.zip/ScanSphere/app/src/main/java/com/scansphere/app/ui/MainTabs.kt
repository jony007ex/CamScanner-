@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.scansphere.app.data.Category
import com.scansphere.app.data.Doc
import com.scansphere.app.data.Tags
import com.scansphere.app.util.L10n
import com.scansphere.app.util.tr

// ======================= HOME =======================

private class QuickAction(val icon: ImageVector, val label: String, val onClick: () -> Unit)

@Composable
fun HomeScreen(c: AppController) {
    var query by remember { mutableStateOf("") }
    val list = c.docs.filter { it.name.contains(query.trim(), ignoreCase = true) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(tr("Search", "খুঁজুন")) },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = {
                    c.info = Pair(
                        tr("Cloud", "ক্লাউড"),
                        tr(
                            "Open any file and tap Google Drive or OneDrive to save it to the cloud. The official app must be installed and signed in.",
                            "যেকোনো ফাইল খুলে Google Drive বা OneDrive চাপুন, ফাইলটা ক্লাউডে সেভ হবে। ফোনে অফিসিয়াল অ্যাপটা ইনস্টল ও সাইন-ইন থাকতে হবে।"
                        )
                    )
                }) { Icon(Icons.Filled.Cloud, null, tint = Color(0xFF4A9BFF)) }
            }
        }
        item {
            val quick = listOf(
                QuickAction(Icons.Filled.DocumentScanner, tr("Smart Scan", "স্মার্ট স্ক্যান")) { c.startScan(ScanMode.DOCUMENT) },
                QuickAction(Icons.Filled.PictureAsPdf, tr("PDF Tools", "PDF টুলস")) { c.tab = Tab.TOOLS },
                QuickAction(Icons.Filled.Image, tr("Import Images", "ছবি ইমপোর্ট")) { c.pickImages(PickMode.IMPORT) },
                QuickAction(Icons.Filled.UploadFile, tr("Import Files", "PDF ইমপোর্ট")) { c.pickPdf() },
                QuickAction(Icons.Filled.Badge, tr("ID Cards", "আইডি কার্ড")) { c.startScan(ScanMode.ID_CARD) },
                QuickAction(Icons.Filled.TextFields, tr("Extract Text", "টেক্সট বের করুন")) { c.startScan(ScanMode.EXTRACT_TEXT) },
                QuickAction(Icons.Filled.ContactPage, tr("Business Card", "ভিজিটিং কার্ড")) { c.startScan(ScanMode.BUSINESS_CARD) },
                QuickAction(Icons.Filled.Apps, tr("All", "সব টুলস")) { c.tab = Tab.TOOLS },
            )
            val colors = listOf(Teal, Color(0xFFFF6B4A), Color(0xFF4A7DFF), Color(0xFF4A7DFF), Teal, Teal, Color(0xFF4A7DFF), Teal)
            Column(Modifier.padding(horizontal = 8.dp)) {
                quick.chunked(4).forEachIndexed { r, row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEachIndexed { i, q ->
                            ToolTile(q.icon, q.label, colors[r * 4 + i], Modifier.weight(1f), onClick = q.onClick)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                SectionHeader(tr("Recents", "সাম্প্রতিক"), Modifier.weight(1f))
                TextButton(onClick = { c.tab = Tab.FILES }) {
                    Text(tr("View All", "সব দেখুন"))
                    Icon(Icons.Filled.ChevronRight, null)
                }
            }
        }
        if (list.isEmpty()) {
            item {
                EmptyState(
                    Icons.Filled.FolderOpen,
                    tr("No files yet", "এখনো কোনো ফাইল নেই"),
                    tr("Tap the camera button to scan your first document.", "ক্যামেরা বাটন চেপে প্রথম ডকুমেন্ট স্ক্যান করুন।"),
                )
            }
        }
        items(list.take(20), key = { it.id }) { doc ->
            DocRow(c, doc, selected = null, onToggle = {}, onClick = { c.openDoc(doc) })
            if (doc == list.first() && !doc.locked) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { c.sharePdf(doc) }, modifier = Modifier.weight(1f)) { Text(tr("Share", "শেয়ার")) }
                    FilledTonalButton(onClick = { c.toWord(doc) }, modifier = Modifier.weight(1f)) { Text(tr("To Word", "Word")) }
                    FilledTonalButton(onClick = { c.openDoc(doc) }, modifier = Modifier.weight(1f)) { Text(tr("View", "দেখুন")) }
                }
                HorizontalDivider(Modifier.padding(top = 10.dp))
            }
        }
    }
}

// ======================= FILES =======================

private enum class SortMode { NEWEST, OLDEST, NAME }

@Composable
fun FilesScreen(c: AppController) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var folder by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(SortMode.NEWEST) }
    var grid by remember { mutableStateOf(false) }
    var selecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var newFolder by remember { mutableStateOf(false) }
    var moveDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }

    val filters: List<Pair<String, String>> = listOf(
        "all" to tr("All", "সব"),
        "cat:" + Category.SCAN to tr("Scan", "স্ক্যান"),
        "cat:" + Category.PDF to "PDF",
    ) + Tags.ALL.map { "tag:$it" to it }

    var list = c.docs.filter { d ->
        d.name.contains(query.trim(), ignoreCase = true) &&
            (folder.isEmpty() || d.folder == folder) &&
            when {
                filter == "all" -> true
                filter.startsWith("cat:") -> d.category == filter.removePrefix("cat:")
                else -> d.tags.contains(filter.removePrefix("tag:"))
            }
    }
    list = when (sort) {
        SortMode.NEWEST -> list.sortedByDescending { it.modified }
        SortMode.OLDEST -> list.sortedBy { it.modified }
        SortMode.NAME -> list.sortedBy { it.name.lowercase() }
    }
    val chosen = c.docs.filter { it.id in selected }

    fun toggle(d: Doc) {
        selected = if (d.id in selected) selected - d.id else selected + d.id
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigCardButton(Icons.Filled.UploadFile, tr("Import Files", "PDF ইমপোর্ট"), Color(0xFF4A7DFF), Modifier.weight(1f)) { c.pickPdf() }
            BigCardButton(Icons.Filled.Image, tr("Import Images", "ছবি ইমপোর্ট"), Teal, Modifier.weight(1f)) { c.pickImages(PickMode.IMPORT) }
            BigCardButton(Icons.Filled.CreateNewFolder, tr("Create Folder", "ফোল্ডার তৈরি"), Color(0xFF4A7DFF), Modifier.weight(1f)) { newFolder = true }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text(tr("Search files", "ফাইল খুঁজুন")) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        )
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                (if (folder.isEmpty()) tr("All", "সব") else folder) + " (" + list.size + ")",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = {
                sort = when (sort) {
                    SortMode.NEWEST -> SortMode.OLDEST
                    SortMode.OLDEST -> SortMode.NAME
                    SortMode.NAME -> SortMode.NEWEST
                }
                c.toast(
                    when (sort) {
                        SortMode.NEWEST -> tr("Newest first", "নতুনগুলো আগে")
                        SortMode.OLDEST -> tr("Oldest first", "পুরোনোগুলো আগে")
                        SortMode.NAME -> tr("By name", "নাম অনুযায়ী")
                    }
                )
            }) { Icon(Icons.Filled.FilterList, null) }
            IconButton(onClick = { grid = !grid }) { Icon(if (grid) Icons.Filled.ViewAgenda else Icons.Filled.GridView, null) }
            IconButton(onClick = {
                selecting = !selecting
                selected = emptySet()
            }) { Icon(if (selecting) Icons.Filled.Close else Icons.Filled.CheckBox, null) }
        }
        if (c.folders.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = folder.isEmpty(), onClick = { folder = "" }, label = { Text(tr("All folders", "সব ফোল্ডার")) },
                    leadingIcon = { Icon(Icons.Filled.Folder, null, Modifier.size(18.dp)) })
                c.folders.forEach { f ->
                    FilterChip(selected = folder == f, onClick = { folder = f }, label = { Text(f) },
                        leadingIcon = { Icon(Icons.Filled.Folder, null, Modifier.size(18.dp)) })
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            filters.forEach { (key, label) ->
                FilterChip(selected = filter == key, onClick = { filter = key }, label = { Text(label) })
            }
        }

        Box(Modifier.weight(1f)) {
            if (list.isEmpty()) {
                EmptyState(Icons.Filled.FolderOpen, tr("No files", "কোনো ফাইল নেই"), tr("Nothing matches this filter.", "এই ফিল্টারে কোনো ফাইল নেই।"))
            } else if (grid) {
                LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 90.dp)) {
                    items(list, key = { it.id }) { d ->
                        DocGridItem(c, d, if (selecting) d.id in selected else null, { toggle(d) }) {
                            if (selecting) toggle(d) else c.openDoc(d)
                        }
                    }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
                    items(list, key = { it.id }) { d ->
                        DocRow(c, d, if (selecting) d.id in selected else null, { toggle(d) }) {
                            if (selecting) toggle(d) else c.openDoc(d)
                        }
                    }
                }
            }
        }

        if (selecting && selected.isNotEmpty()) {
            Surface(tonalElevation = 6.dp) {
                Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    ActionItem(Icons.Filled.Share, tr("Share", "শেয়ার")) { c.sharePdfs(chosen) }
                    ActionItem(Icons.Filled.MergeType, tr("Merge", "একত্র")) {
                        if (chosen.size < 2) c.toast(tr("Select at least 2 files", "অন্তত ২টা ফাইল বাছুন")) else {
                            c.merge(chosen)
                            selecting = false
                            selected = emptySet()
                        }
                    }
                    ActionItem(Icons.Filled.DriveFileMove, tr("Move", "সরান")) { moveDialog = true }
                    ActionItem(Icons.Filled.Delete, tr("Delete", "ডিলিট")) { deleteDialog = true }
                }
            }
        }
    }

    if (newFolder) {
        InputDialog(tr("Create folder", "ফোল্ডার তৈরি"), "", tr("Folder name", "ফোল্ডারের নাম"),
            onDismiss = { newFolder = false }) {
            c.repo.addFolder(it)
            c.refresh()
            newFolder = false
        }
    }
    if (moveDialog) {
        AlertDialog(
            onDismissRequest = { moveDialog = false },
            title = { Text(tr("Move to folder", "ফোল্ডারে সরান")) },
            text = {
                Column {
                    if (c.folders.isEmpty()) Text(tr("Create a folder first.", "আগে একটা ফোল্ডার তৈরি করুন।"))
                    (listOf("") + c.folders).forEach { f ->
                        Text(
                            if (f.isEmpty()) tr("No folder", "কোনো ফোল্ডার না") else f,
                            Modifier.fillMaxWidth().clickable {
                                chosen.forEach { c.repo.setFolder(it, f) }
                                c.refresh()
                                moveDialog = false
                                selecting = false
                                selected = emptySet()
                            }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { moveDialog = false }) { Text(tr("Close", "বন্ধ")) } },
        )
    }
    if (deleteDialog) {
        ConfirmDialog(
            tr("Delete files?", "ফাইল ডিলিট করবেন?"),
            tr("${chosen.size} file(s) will be deleted permanently.", "${chosen.size}টা ফাইল স্থায়ীভাবে মুছে যাবে।"),
            tr("Delete", "ডিলিট"),
            onDismiss = { deleteDialog = false },
        ) {
            c.deleteDocs(chosen)
            deleteDialog = false
            selecting = false
            selected = emptySet()
        }
    }
}

@Composable
private fun BigCardButton(icon: ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
    }
}

// ======================= TOOLS =======================

@Composable
fun ToolsScreen(c: AppController) {
    val sections = listOf(
        ToolSection.SCAN to tr("Scan", "স্ক্যান"),
        ToolSection.IMPORT to tr("Import", "ইমপোর্ট"),
        ToolSection.CONVERT to tr("Convert", "রূপান্তর"),
        ToolSection.EDIT to tr("Edit", "এডিট"),
        ToolSection.UTILITIES to tr("Utilities", "অন্যান্য"),
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 8.dp)) {
        sections.forEach { (section, title) ->
            SectionHeader(title, Modifier.padding(start = 12.dp, top = 12.dp, bottom = 4.dp))
            Tool.entries.filter { it.section == section }.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { t ->
                        ToolTile(
                            t.icon, tr(t.en, t.bn), t.color, Modifier.weight(1f),
                            badge = if (t.ready) null else tr("Soon", "শীঘ্রই"),
                        ) { c.onTool(t) }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ======================= ME =======================

@Composable
fun MeScreen(c: AppController) {
    var nameDialog by remember { mutableStateOf(false) }
    var prefixDialog by remember { mutableStateOf(false) }
    var langDialog by remember { mutableStateOf(false) }
    val used = remember(c.docs) { c.repo.storageBytes() }
    val usedText = android.text.format.Formatter.formatShortFileSize(c.context, used)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier.fillMaxWidth().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFFF5C77E), Color(0xFFE9A94B)))
            ).padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                    Text(
                        c.userName.take(1).uppercase().ifEmpty { "S" },
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color(0xFFB27222),
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        c.userName.ifEmpty { tr("Tap to set your name", "নাম দিতে ট্যাপ করুন") },
                        style = MaterialTheme.typography.titleLarge,
                        color = Color(0xFF3A2A10),
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { nameDialog = true },
                    )
                    Text(
                        tr("On this phone: ", "ফোনে ব্যবহৃত: ") + usedText + "  •  " + c.docs.size + tr(" files", "টা ফাইল"),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF5A4520),
                    )
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                MeQuick(Icons.Filled.CloudUpload, tr("Cloud", "ক্লাউড"), Color(0xFF4A9BFF), Modifier.weight(1f)) {
                    c.info = Pair(tr("Cloud", "ক্লাউড"), tr(
                        "Open a file and tap Google Drive or OneDrive to back it up.",
                        "ফাইল খুলে Google Drive বা OneDrive চাপলেই ব্যাকআপ হবে।"))
                }
                MeQuick(Icons.Filled.QrCodeScanner, tr("QR History", "QR হিস্ট্রি"), Color(0xFFFF6B6B), Modifier.weight(1f)) { c.push(Screen.QrHistory) }
                MeQuick(Icons.Filled.Folder, tr("Files", "ফাইল"), Color(0xFFF5B83D), Modifier.weight(1f)) { c.tab = Tab.FILES }
            }
        }

        Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            MeRow(Icons.Filled.Person, tr("Account", "অ্যাকাউন্ট"), c.userName) { nameDialog = true }
            MeRow(Icons.Filled.Sync, tr("Sync", "সিঙ্ক"), "Google Drive / OneDrive") {
                c.info = Pair(tr("Sync", "সিঙ্ক"), tr(
                    "Files are stored on this phone. Use Google Drive or OneDrive from any file to keep a cloud copy.",
                    "ফাইল এই ফোনে থাকে। ক্লাউডে কপি রাখতে যেকোনো ফাইল থেকে Google Drive বা OneDrive ব্যবহার করুন।"))
            }
            MeRow(Icons.Filled.DocumentScanner, tr("Scan settings", "স্ক্যান সেটিংস"), tr("File name: ", "ফাইলের নাম: ") + c.prefix) { prefixDialog = true }
            MeRow(Icons.Filled.Description, tr("Manage Documents", "ডকুমেন্ট ম্যানেজ"), "") { c.tab = Tab.FILES }
            MeRow(Icons.Filled.Language, tr("Language", "ভাষা"), if (L10n.bangla) "বাংলা" else "English") { langDialog = true }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            MeRow(Icons.Filled.Print, tr("My printer", "আমার প্রিন্টার"), "") { c.onTool(Tool.PRINT) }
            MeRow(Icons.Filled.ThumbUp, tr("Recommend", "শেয়ার করে জানান"), "") { c.recommend() }
            MeRow(Icons.Filled.Info, tr("Help", "সাহায্য"), "") {
                c.info = Pair(tr("Help", "সাহায্য"), tr(
                    "• Camera button: scan documents (auto edge detection, crop, filters).\n• Tools: ID cards, books, text extraction, translation, sign, watermark, merge and more.\n• Open a file to share PDF, save to cloud, edit pages or print.",
                    "• ক্যামেরা বাটন: ডকুমেন্ট স্ক্যান (অটো এজ ডিটেকশন, ক্রপ, ফিল্টার)।\n• টুলস: আইডি কার্ড, বই, লেখা বের করা, অনুবাদ, স্বাক্ষর, ওয়াটারমার্ক, ফাইল একত্র ইত্যাদি।\n• ফাইল খুলে PDF শেয়ার, ক্লাউডে সেভ, পেজ এডিট বা প্রিন্ট করুন।"))
            }
            MeRow(Icons.Filled.Feedback, tr("Feedback", "মতামত"), "") { c.sendFeedback() }
            MeRow(Icons.Filled.Shield, tr("Privacy", "প্রাইভেসি"), "") {
                c.info = Pair(tr("Privacy", "প্রাইভেসি"), tr(
                    "Scanning and text recognition run on your phone. Nothing is uploaded unless you share it.",
                    "স্ক্যান আর লেখা পড়া আপনার ফোনেই হয়। আপনি শেয়ার না করলে কিছুই আপলোড হয় না।"))
            }
            MeRow(Icons.Filled.Info, tr("About", "অ্যাপ সম্পর্কে"), "ScanSphere 2.0.0") {}
        }
        Spacer(Modifier.height(24.dp))
    }

    if (nameDialog) {
        InputDialog(tr("Your name", "আপনার নাম"), c.userName, tr("Name", "নাম"), onDismiss = { nameDialog = false }) {
            c.setUser(it)
            nameDialog = false
        }
    }
    if (prefixDialog) {
        InputDialog(tr("File name prefix", "ফাইলের নামের শুরু"), c.prefix, tr("Prefix", "শুরুর অংশ"), onDismiss = { prefixDialog = false }) {
            c.setPrefixName(it)
            prefixDialog = false
        }
    }
    if (langDialog) {
        AlertDialog(
            onDismissRequest = { langDialog = false },
            title = { Text(tr("Language", "ভাষা")) },
            text = {
                Column {
                    listOf(true to "বাংলা", false to "English").forEach { (bn, label) ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                L10n.set(c.context, bn)
                                langDialog = false
                            }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = L10n.bangla == bn, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Text(label)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { langDialog = false }) { Text(tr("Close", "বন্ধ")) } },
        )
    }
}

@Composable
private fun MeQuick(icon: ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MeRow(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(18.dp))
        Text(title, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) {
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}
