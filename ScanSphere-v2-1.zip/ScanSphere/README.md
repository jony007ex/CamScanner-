# ScanSphere 2.0: CamScanner-style All-in-One Scanner (Android)

## Structure (same as CamScanner)
- **Home:** search, 8 quick tools, recent files (Share / To Word / View), camera button
- **Files:** Import Files / Import Images / Create Folder, search, folders, filters (Scan, PDF, ID Card, Business Card, Note, PPT, Whiteboard, Book), sort, grid/list, multi-select (Share, Merge, Move, Delete)
- **Tools:** Scan, Import, Convert, Edit, Utilities sections
- **Me:** profile, storage, cloud, sync, scan settings, language, printer, recommend, help, feedback

## Working tools
ID Cards (front + back on one A4 page), Extract Text, ID Photo Maker (4x6 print sheet), Business Card → Contacts, Photo Translation (English → Bangla), Book (splits two pages), Slides, Whiteboard, Timestamp, Import Images, Import PDF, To Word (.docx), PDF to Images, PDF to Long Image, Sign, Add Watermark, Erase Marks, Merge Files, Extract Pages, Reorder Pages, Lock (PIN), Print, Scan Code (QR → Contacts), QR History, Filters, Rotate, Add page, Delete page, Tags, Folders, Google Drive, OneDrive.

Marked "Soon": Formula, To Excel, To PPT, Smart Erase, Restore Photo, AI Assistant, CountCam (these need online AI services).

## Build
Upload `ScanSphere-v2.zip` (not extracted) to the GitHub repository root, and use the workflow in `.github/workflows/main.yml`.
