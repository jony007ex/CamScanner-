# ScanSphere: All-in-One Smart Scanner (Android MVP)

ডকুমেন্ট স্ক্যানার, ভিজিটিং কার্ড থেকে কন্টাক্ট, QR থেকে কন্টাক্ট আর Google Drive / OneDrive-এ সেভ, সব এক অ্যাপে।

## ফিচার (v1.0.0 MVP)

| মডিউল | যা আছে |
|---|---|
| ডকুমেন্ট স্ক্যান | অটো এজ ডিটেকশন, অটো ক্যাপচার, ক্রপ, রোটেট, ফিল্টার, দাগ/ছায়া মোছা, একসাথে ৫০ পেজ, গ্যালারি থেকে ইমপোর্ট, PDF হিসেবে সেভ |
| ভিজিটিং কার্ড | কার্ড স্ক্যান → অন-ডিভাইস OCR → নাম, পদবি, প্রতিষ্ঠান, মোবাইল, অফিস ফোন, ইমেইল, ওয়েবসাইট, ঠিকানা আলাদা করা → এডিট → Contacts-এ সেভ / vCard শেয়ার |
| QR / বারকোড | সব ধরনের QR ও বারকোড; vCard/MeCard QR → Contacts-এ সেভ; লিংক, Wi-Fi, ফোন, ইমেইল, SMS অ্যাকশন; স্ক্যান হিস্ট্রি |
| ক্লাউড | যেকোনো ফাইল এক ট্যাপে Google Drive বা OneDrive-এ সেভ (অফিসিয়াল অ্যাপের মাধ্যমে) |
| ফাইল | সার্চ, ওপেন, শেয়ার, Rename, Delete, JPG হিসেবে এক্সপোর্ট |
| অন্যান্য | বাংলা + English ইন্টারফেস, Light/Dark মোড, ক্যামেরা বা কন্টাক্ট পারমিশন লাগে না |

**ফোনের শর্ত:** Android 8.0 বা নতুন, Google Play services থাকতে হবে। প্রথমবার স্ক্যানার চালু করলে Google একটা ছোট মডিউল ডাউনলোড করে, তাই তখন ইন্টারনেট লাগবে।

---

## APK বানানোর পদ্ধতি ১: GitHub দিয়ে (কোনো সফটওয়্যার ইনস্টল ছাড়া, ফ্রি)

1. https://github.com এ একটা ফ্রি অ্যাকাউন্ট খুলুন।
2. উপরে **+ → New repository** → নাম দিন `ScanSphere` → **Private** রাখতে পারেন → **Create repository**।
3. **uploading an existing file** লিংকে ক্লিক করুন। ZIP খুলে ভেতরের **সব ফাইল ও ফোল্ডার** টেনে এনে ছেড়ে দিন → **Commit changes**।
4. উপরে **Actions** ট্যাবে যান।
   - যদি "Build ScanSphere APK" দেখা যায়, সেটা নিজে থেকেই চলা শুরু করবে।
   - যদি না দেখা যায় (কম্পিউটার অনেক সময় `.github` লুকানো ফোল্ডার আপলোড করে না): **set up a workflow yourself** চাপুন → `github-workflow-build-apk.yml` ফাইলের পুরো লেখা কপি করে পেস্ট করুন → **Commit changes**।
5. ৮ থেকে ১২ মিনিট অপেক্ষা করুন। সবুজ ✓ চিহ্ন এলে বিল্ডটায় ক্লিক করুন।
6. নিচে **Artifacts** অংশে **ScanSphere-APK** ডাউনলোড করুন। ZIP খুললেই `ScanSphere-v1.0.0.apk` পাবেন।

## APK বানানোর পদ্ধতি ২: Android Studio দিয়ে

1. Android Studio (Koala বা নতুন) ইনস্টল করুন।
2. **File → Open** → `ScanSphere` ফোল্ডার সিলেক্ট করুন। Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**।
4. APK পাবেন: `app/build/outputs/apk/debug/app-debug.apk`

## ফোনে ইনস্টল

1. APK ফাইলটা ফোনে পাঠান (USB, Google Drive, Teams বা WhatsApp)।
2. ফাইলে ট্যাপ করুন। "Install unknown apps" জিজ্ঞেস করলে **Allow** দিন।
3. Play Protect সতর্কতা দেখালে **Install anyway** চাপুন (নিজে বানানো অ্যাপে এটা স্বাভাবিক)।

---

## প্রজেক্টের গঠন

```
app/src/main/java/com/scansphere/app/
├── MainActivity.kt
├── data/      Models, FileRepository (PDF স্টোরেজ), HistoryStore (QR হিস্ট্রি)
├── util/      CardParser (কার্ডের তথ্য আলাদা করা), CardRecognizer (OCR), QrMapper,
│              ContactSaver (Contacts-এ সেভ, vCard), FileActions (শেয়ার, ক্লাউড, JPG)
└── ui/        ScanSphereApp (নেভিগেশন), Home, Files, QR/History, CardReview, Settings, Theme
```

**টেকনোলজি:** Kotlin, Jetpack Compose (Material 3), Google ML Kit Document Scanner, ML Kit Code Scanner, ML Kit Text Recognition (অফলাইন)।

## সীমাবদ্ধতা ও পরের ধাপ

- **বাংলা কার্ড:** ML Kit বাংলা লিপি পড়তে পারে না। এখন শুধু ইংরেজি কার্ড ঠিকমতো পড়া যাবে।
- **ক্লাউড:** এখন Drive/OneDrive অ্যাপের মাধ্যমে সেভ হয়। অটো-আপলোড চাইলে Google Cloud Console আর Azure-এ অ্যাপ রেজিস্টার করে Drive API ও Microsoft Graph API যোগ করতে হবে (রোডম্যাপের v1.1)।
- **এই APK টেস্টিংয়ের জন্য:** debug key দিয়ে সাইন করা। Play Store-এ দিতে হলে নিজের release keystore দিয়ে সাইন করে AAB বানাতে হবে।
- **অ্যাপের নাম ও প্যাকেজ:** `app/src/main/res/values/strings.xml` এ `app_name`, আর `app/build.gradle.kts` এ `applicationId` বদলান।
