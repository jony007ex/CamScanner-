package com.scansphere.app.util

import com.scansphere.app.data.ContactData

/** One line of recognised text and its height on the card (bigger text = more important). */
data class CardLine(val text: String, val height: Int)

/**
 * Turns the raw text of a visiting card into contact fields using simple rules.
 * Tuned for English cards, including Bangladesh phone numbers and addresses.
 */
object CardParser {

    private val EMAIL = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val WEB = Regex(
        "(?i)(https?://)?(www\\.)?[a-z0-9-]+(\\.[a-z0-9-]+)*\\." +
            "(com|net|org|info|biz|io|ai|app|tech|xyz|edu|gov|bd|in|uk|us)(\\.[a-z]{2})?(/\\S*)?"
    )
    private val PHONE = Regex("\\+?\\(?\\d[\\d\\s().\\-/]{5,}\\d")
    private val BD_MOBILE = Regex("^(?:880|0)?1[3-9]\\d{8}$")
    private val TOKEN_SPLIT = Regex("[^a-z0-9&]+")

    private val TITLE_WORDS = setOf(
        "ceo", "cto", "cfo", "coo", "cio", "md", "avp", "vp", "svp", "evp", "gm", "agm", "dgm",
        "manager", "director", "officer", "engineer", "executive", "president", "head", "lead",
        "assistant", "consultant", "developer", "designer", "chairman", "founder", "cofounder",
        "specialist", "analyst", "coordinator", "supervisor", "advisor", "adviser", "architect",
        "partner", "accountant", "secretary", "representative", "associate", "professor",
        "lecturer", "proprietor", "owner", "incharge", "administrator", "controller",
    )
    private val COMPANY_WORDS = setOf(
        "ltd", "limited", "inc", "corp", "corporation", "company", "bank", "group", "industries",
        "industry", "solutions", "solution", "technologies", "technology", "plc", "llc", "llp",
        "enterprise", "enterprises", "associates", "foundation", "university", "consultancy",
        "consulting", "services", "systems", "international", "pharmaceuticals", "pharma",
        "textiles", "garments", "agency", "studio", "trading", "holdings", "insurance", "finance",
        "hospital", "clinic", "school", "college", "institute", "pvt", "co",
    )
    private val ADDRESS_WORDS = setOf(
        "road", "rd", "street", "st", "house", "floor", "avenue", "ave", "lane", "sector", "block",
        "tower", "building", "plaza", "suite", "level", "dhaka", "chittagong", "chattogram",
        "sylhet", "khulna", "rajshahi", "barishal", "rangpur", "gulshan", "banani", "dhanmondi",
        "motijheel", "uttara", "mirpur", "tejgaon", "mohakhali", "bashundhara", "bangladesh",
        "po", "box", "city", "district", "area",
    )

    private fun tokens(s: String): List<String> = s.lowercase().split(TOKEN_SPLIT).filter { it.isNotEmpty() }

    private fun cleanPhone(s: String): String = s.trim().replace(Regex("\\s+"), " ")

    private fun isBdMobile(p: String): Boolean = BD_MOBILE.matches(p.filter { it.isDigit() })

    fun parse(lines: List<CardLine>): ContactData {
        var email = ""
        var website = ""
        val phones = mutableListOf<String>()
        val used = BooleanArray(lines.size)

        // 1) Email, phone and website are easy to detect with patterns.
        lines.forEachIndexed { i, line ->
            val text = line.text
            EMAIL.find(text)?.let { m ->
                if (email.isEmpty()) email = m.value
                used[i] = true
            }
            val withoutEmail = EMAIL.replace(text, " ")
            val isFax = text.contains("fax", ignoreCase = true)
            PHONE.findAll(withoutEmail).forEach { m ->
                val digits = m.value.count { it.isDigit() }
                if (digits in 7..15) {
                    if (!isFax) phones += cleanPhone(m.value)
                    used[i] = true
                }
            }
            if (website.isEmpty()) {
                WEB.find(withoutEmail)?.let { m ->
                    if (m.value.any { it.isLetter() }) {
                        website = m.value
                        used[i] = true
                    }
                }
            }
        }

        val uniquePhones = phones.distinct()
        val mobile = uniquePhones.firstOrNull { isBdMobile(it) } ?: uniquePhones.firstOrNull() ?: ""
        val phone2 = uniquePhones.firstOrNull { it != mobile } ?: ""

        // 2) Classify the remaining lines by keywords.
        var title = ""
        var company = ""
        val address = mutableListOf<String>()
        val others = mutableListOf<CardLine>()

        lines.forEachIndexed { i, line ->
            if (used[i]) return@forEachIndexed
            val text = line.text
            val words = tokens(text)
            when {
                title.isEmpty() && words.any { it in TITLE_WORDS } -> { title = text }
                company.isEmpty() && words.any { it in COMPANY_WORDS } -> { company = text }
                words.any { it in ADDRESS_WORDS } ||
                    (text.any { it.isDigit() } && text.contains(',')) -> { address += text }
                text.length >= 3 -> { others += line }
                else -> {}
            }
        }

        // 3) The name is usually the largest plain-text line with 1 to 5 words.
        fun looksLikeName(s: String): Boolean {
            val wordCount = s.trim().split(Regex("\\s+")).size
            return s.length in 3..40 && wordCount in 1..5 &&
                s.all { it.isLetter() || it == ' ' || it == '.' || it == '-' || it == '\'' }
        }

        val nameLine = others.filter { looksLikeName(it.text) }.maxByOrNull { it.height }
        val name = nameLine?.text ?: ""
        val rest = others.filter { it !== nameLine }.toMutableList()

        if (company.isEmpty()) {
            val companyLine = rest.filter { l -> l.text.none { it.isDigit() } }.maxByOrNull { it.height }
            if (companyLine != null) {
                company = companyLine.text
                rest.remove(companyLine)
            }
        }

        return ContactData(
            name = name,
            title = title,
            company = company,
            mobile = mobile,
            phone2 = phone2,
            email = email,
            website = website,
            address = address.joinToString(", "),
            notes = rest.joinToString("\n") { it.text },
        )
    }
}
