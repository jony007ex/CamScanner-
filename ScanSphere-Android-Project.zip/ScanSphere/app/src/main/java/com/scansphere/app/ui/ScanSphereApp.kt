@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import android.app.Activity
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.scansphere.app.R
import com.scansphere.app.data.ContactData
import com.scansphere.app.data.FileRepository
import com.scansphere.app.data.HistoryStore
import com.scansphere.app.data.QrResult
import com.scansphere.app.util.CardRecognizer
import com.scansphere.app.util.FileActions
import com.scansphere.app.util.QrMapper
import com.scansphere.app.util.findActivity
import kotlinx.coroutines.launch

enum class Tab { HOME, FILES, HISTORY, SETTINGS }

sealed interface Screen {
    data object Main : Screen
    data class CardReview(val data: ContactData, val imageUri: Uri?) : Screen
    data class QrDetail(val result: QrResult) : Screen
}

private fun Tab.icon(): ImageVector = when (this) {
    Tab.HOME -> Icons.Filled.Home
    Tab.FILES -> Icons.Filled.Folder
    Tab.HISTORY -> Icons.Filled.History
    Tab.SETTINGS -> Icons.Filled.Settings
}

private fun Tab.labelRes(): Int = when (this) {
    Tab.HOME -> R.string.tab_home
    Tab.FILES -> R.string.tab_files
    Tab.HISTORY -> R.string.tab_history
    Tab.SETTINGS -> R.string.tab_settings
}

@Composable
fun ScanSphereApp() {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val repo = remember { FileRepository(context.applicationContext) }
    val historyStore = remember { HistoryStore(context.applicationContext) }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    var screen by remember { mutableStateOf<Screen>(Screen.Main) }
    var files by remember { mutableStateOf(repo.list()) }
    var history by remember { mutableStateOf(historyStore.all()) }
    var busy by remember { mutableStateOf(false) }

    val showMessage: (String) -> Unit = { msg ->
        scope.launch { snackbar.showSnackbar(msg) }
    }

    // ---------- Document scanner result ----------
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val pdfUri = GmsDocumentScanningResult.fromActivityResultIntent(res.data)?.pdf?.uri
            val saved = pdfUri?.let { repo.importPdf(it) }
            files = repo.list()
            if (saved != null) {
                showMessage(context.getString(R.string.msg_saved, saved.name))
            } else {
                showMessage(context.getString(R.string.msg_scan_failed))
            }
        }
    }

    // ---------- Visiting card result ----------
    val cardLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val imageUri = GmsDocumentScanningResult.fromActivityResultIntent(res.data)?.pages?.firstOrNull()?.imageUri
            if (imageUri == null) {
                showMessage(context.getString(R.string.msg_scan_failed))
            } else {
                busy = true
                CardRecognizer.recognize(
                    context = context,
                    uri = imageUri,
                    onSuccess = { data ->
                        busy = false
                        screen = Screen.CardReview(data, imageUri)
                    },
                    onError = {
                        busy = false
                        showMessage(context.getString(R.string.msg_ocr_failed))
                    },
                )
            }
        }
    }

    fun startDocumentScanner(cardMode: Boolean) {
        val act = activity
        if (act == null) {
            showMessage(context.getString(R.string.msg_scanner_error))
            return
        }
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(if (cardMode) 1 else 50)
            .setResultFormats(
                if (cardMode) GmsDocumentScannerOptions.RESULT_FORMAT_JPEG
                else GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(act)
            .addOnSuccessListener { sender ->
                val request = IntentSenderRequest.Builder(sender).build()
                if (cardMode) cardLauncher.launch(request) else docLauncher.launch(request)
            }
            .addOnFailureListener { showMessage(context.getString(R.string.msg_scanner_error)) }
    }

    fun startQrScanner() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .enableAutoZoom()
            .build()
        GmsBarcodeScanning.getClient(context, options)
            .startScan()
            .addOnSuccessListener { barcode ->
                val result = QrMapper.from(barcode)
                history = historyStore.add(result)
                screen = Screen.QrDetail(result)
            }
            .addOnFailureListener { showMessage(context.getString(R.string.msg_scanner_error)) }
    }

    BackHandler(enabled = screen != Screen.Main || tab != Tab.HOME) {
        if (screen != Screen.Main) {
            screen = Screen.Main
        } else {
            tab = Tab.HOME
        }
    }

    val title = when (screen) {
        is Screen.CardReview -> stringResource(R.string.title_review_contact)
        is Screen.QrDetail -> stringResource(R.string.title_scan_result)
        Screen.Main -> if (tab == Tab.HOME) stringResource(R.string.app_name) else stringResource(tab.labelRes())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    if (screen != Screen.Main) {
                        IconButton(onClick = { screen = Screen.Main }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                        }
                    }
                },
            )
        },
        bottomBar = {
            if (screen == Screen.Main) {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon(), contentDescription = null) },
                            label = { Text(stringResource(t.labelRes())) },
                        )
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (val s = screen) {
                Screen.Main -> when (tab) {
                    Tab.HOME -> HomeScreen(
                        recent = files.take(5),
                        onScanDocument = { startDocumentScanner(cardMode = false) },
                        onScanCard = { startDocumentScanner(cardMode = true) },
                        onScanQr = { startQrScanner() },
                        onOpenFile = { FileActions.open(context, it) },
                        onSeeAll = { tab = Tab.FILES },
                    )
                    Tab.FILES -> FilesScreen(
                        files = files,
                        repo = repo,
                        onChanged = { files = repo.list() },
                        showMessage = showMessage,
                    )
                    Tab.HISTORY -> HistoryScreen(
                        items = history,
                        onOpen = { screen = Screen.QrDetail(it) },
                        onClear = {
                            historyStore.clear()
                            history = emptyList()
                        },
                        onScan = { startQrScanner() },
                    )
                    Tab.SETTINGS -> SettingsScreen()
                }
                is Screen.CardReview -> CardReviewScreen(
                    initial = s.data,
                    imageUri = s.imageUri,
                    onDone = { screen = Screen.Main },
                )
                is Screen.QrDetail -> QrDetailScreen(
                    result = s.result,
                    onSaveContact = { contact -> screen = Screen.CardReview(contact, null) },
                    showMessage = showMessage,
                )
            }

            if (busy) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {},
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator(color = Color.White)
                        Text(stringResource(R.string.reading_card), color = Color.White)
                    }
                }
            }
        }
    }
}
