package com.scansphere.app.util

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds
import android.widget.Toast
import com.scansphere.app.R
import com.scansphere.app.data.ContactData
import java.io.File

/**
 * Opens the phone's own "New contact" screen pre-filled with the scanned details.
 * The user confirms there, so no contacts permission is needed.
 */
object ContactSaver {

    fun save(context: Context, c: ContactData) {
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            if (c.name.isNotBlank()) putExtra(ContactsContract.Intents.Insert.NAME, c.name.trim())
            if (c.company.isNotBlank()) putExtra(ContactsContract.Intents.Insert.COMPANY, c.company.trim())
            if (c.title.isNotBlank()) putExtra(ContactsContract.Intents.Insert.JOB_TITLE, c.title.trim())
            if (c.mobile.isNotBlank()) {
                putExtra(ContactsContract.Intents.Insert.PHONE, c.mobile.trim())
                putExtra(ContactsContract.Intents.Insert.PHONE_TYPE, CommonDataKinds.Phone.TYPE_MOBILE)
            }
            if (c.phone2.isNotBlank()) {
                putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, c.phone2.trim())
                putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE_TYPE, CommonDataKinds.Phone.TYPE_WORK)
            }
            if (c.email.isNotBlank()) {
                putExtra(ContactsContract.Intents.Insert.EMAIL, c.email.trim())
                putExtra(ContactsContract.Intents.Insert.EMAIL_TYPE, CommonDataKinds.Email.TYPE_WORK)
            }
            if (c.address.isNotBlank()) {
                putExtra(ContactsContract.Intents.Insert.POSTAL, c.address.trim())
                putExtra(ContactsContract.Intents.Insert.POSTAL_TYPE, CommonDataKinds.StructuredPostal.TYPE_WORK)
            }
            if (c.notes.isNotBlank()) putExtra(ContactsContract.Intents.Insert.NOTES, c.notes.trim())
            if (c.website.isNotBlank()) {
                val rows = arrayListOf(
                    ContentValues().apply {
                        put(ContactsContract.Data.MIMETYPE, CommonDataKinds.Website.CONTENT_ITEM_TYPE)
                        put(CommonDataKinds.Website.URL, c.website.trim())
                        put(CommonDataKinds.Website.TYPE, CommonDataKinds.Website.TYPE_WORK)
                    }
                )
                putParcelableArrayListExtra(ContactsContract.Intents.Insert.DATA, rows)
            }
            putExtra("finishActivityOnSaveCompleted", true)
        }
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, R.string.msg_no_app, Toast.LENGTH_SHORT).show()
        }
    }

    fun toVcard(c: ContactData): String = buildString {
        fun esc(s: String) = s.trim().replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")
        append("BEGIN:VCARD\r\nVERSION:3.0\r\n")
        append("FN:").append(esc(c.name)).append("\r\n")
        append("N:").append(esc(c.name)).append(";;;;\r\n")
        if (c.company.isNotBlank()) append("ORG:").append(esc(c.company)).append("\r\n")
        if (c.title.isNotBlank()) append("TITLE:").append(esc(c.title)).append("\r\n")
        if (c.mobile.isNotBlank()) append("TEL;TYPE=CELL:").append(c.mobile.trim()).append("\r\n")
        if (c.phone2.isNotBlank()) append("TEL;TYPE=WORK:").append(c.phone2.trim()).append("\r\n")
        if (c.email.isNotBlank()) append("EMAIL;TYPE=WORK:").append(c.email.trim()).append("\r\n")
        if (c.website.isNotBlank()) append("URL:").append(c.website.trim()).append("\r\n")
        if (c.address.isNotBlank()) append("ADR;TYPE=WORK:;;").append(esc(c.address)).append(";;;;\r\n")
        if (c.notes.isNotBlank()) append("NOTE:").append(esc(c.notes)).append("\r\n")
        append("END:VCARD\r\n")
    }

    fun shareVcard(context: Context, c: ContactData) {
        val dir = File(context.cacheDir, "export").apply { mkdirs() }
        val safeName = c.name.ifBlank { "contact" }.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifBlank { "contact" }
        val file = File(dir, "$safeName.vcf")
        file.writeText(toVcard(c))
        FileActions.share(context, listOf(file), "text/x-vcard")
    }
}
