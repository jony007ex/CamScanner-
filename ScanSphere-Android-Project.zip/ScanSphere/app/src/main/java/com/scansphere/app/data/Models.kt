package com.scansphere.app.data

import org.json.JSONObject

/** Contact details collected from a visiting card or a QR code. */
data class ContactData(
    val name: String = "",
    val title: String = "",
    val company: String = "",
    val mobile: String = "",
    val phone2: String = "",
    val email: String = "",
    val website: String = "",
    val address: String = "",
    val notes: String = "",
) {
    fun hasAnyValue(): Boolean =
        listOf(name, title, company, mobile, phone2, email, website, address).any { it.isNotBlank() }

    fun toJson(): JSONObject = JSONObject()
        .put("name", name).put("title", title).put("company", company)
        .put("mobile", mobile).put("phone2", phone2).put("email", email)
        .put("website", website).put("address", address).put("notes", notes)

    companion object {
        fun fromJson(o: JSONObject) = ContactData(
            name = o.optString("name"), title = o.optString("title"),
            company = o.optString("company"), mobile = o.optString("mobile"),
            phone2 = o.optString("phone2"), email = o.optString("email"),
            website = o.optString("website"), address = o.optString("address"),
            notes = o.optString("notes"),
        )
    }
}

enum class QrKind { CONTACT, URL, WIFI, PHONE, EMAIL, SMS, TEXT, OTHER }

/** A single QR / barcode scan result. */
data class QrResult(
    val kind: QrKind,
    val raw: String,
    val display: String,
    val contact: ContactData? = null,
    val wifiSsid: String = "",
    val wifiPassword: String = "",
    val time: Long = System.currentTimeMillis(),
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
            .put("kind", kind.name).put("raw", raw).put("display", display)
            .put("ssid", wifiSsid).put("password", wifiPassword).put("time", time)
        if (contact != null) o.put("contact", contact.toJson())
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): QrResult {
            val kind = runCatching { QrKind.valueOf(o.optString("kind")) }.getOrDefault(QrKind.TEXT)
            val contactJson = o.optJSONObject("contact")
            return QrResult(
                kind = kind,
                raw = o.optString("raw"),
                display = o.optString("display"),
                contact = contactJson?.let { ContactData.fromJson(it) },
                wifiSsid = o.optString("ssid"),
                wifiPassword = o.optString("password"),
                time = o.optLong("time", System.currentTimeMillis()),
            )
        }
    }
}
