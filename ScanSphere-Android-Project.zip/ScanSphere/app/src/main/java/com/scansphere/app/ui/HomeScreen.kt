@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContactPage
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.scansphere.app.R
import java.io.File

@Composable
fun HomeScreen(
    recent: List<File>,
    onScanDocument: () -> Unit,
    onScanCard: () -> Unit,
    onScanQr: () -> Unit,
    onOpenFile: (File) -> Unit,
    onSeeAll: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(Modifier.padding(bottom = 4.dp)) {
                Text(
                    stringResource(R.string.home_greeting),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    stringResource(R.string.home_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onSurfaceVariant,
                )
            }
        }
        item {
            ActionCard(Icons.Filled.DocumentScanner, R.string.action_scan_doc, R.string.action_scan_doc_desc,
                colors.primaryContainer, onScanDocument)
        }
        item {
            ActionCard(Icons.Filled.ContactPage, R.string.action_scan_card, R.string.action_scan_card_desc,
                colors.secondaryContainer, onScanCard)
        }
        item {
            ActionCard(Icons.Filled.QrCodeScanner, R.string.action_scan_qr, R.string.action_scan_qr_desc,
                colors.tertiaryContainer, onScanQr)
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.recent_files),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                if (recent.isNotEmpty()) {
                    TextButton(onClick = onSeeAll) { Text(stringResource(R.string.see_all)) }
                }
            }
        }
        if (recent.isEmpty()) {
            item {
                EmptyState(
                    Icons.Filled.FolderOpen,
                    stringResource(R.string.empty_files_title),
                    stringResource(R.string.empty_files_desc),
                )
            }
        } else {
            items(recent, key = { it.absolutePath }) { file ->
                Card(Modifier.fillMaxWidth()) {
                    FileRow(file, onClick = { onOpenFile(file) })
                }
            }
        }
    }
}

@Composable
private fun ActionCard(
    icon: ImageVector,
    @StringRes title: Int,
    @StringRes subtitle: Int,
    container: Color,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = container),
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(40.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(stringResource(subtitle), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
