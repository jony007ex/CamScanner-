@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContactPage
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scansphere.app.R
import com.scansphere.app.data.ContactData
import com.scansphere.app.data.QrKind
import com.scansphere.app.data.QrResult
import com.scansphere.app.util.FileActions

@StringRes
fun QrKind.labelRes(): Int = when (this) {
    QrKind.CONTACT -> R.string.kind_contact
    QrKind.URL -> R.string.kind_url
    QrKind.WIFI -> R.string.kind_wifi
    QrKind.PHONE -> R.string.kind_phone
    QrKind.EMAIL -> R.string.kind_email
    QrKind.SMS -> R.string.kind_sms
    QrKind.TEXT -> R.string.kind_text
    QrKind.OTHER -> R.string.kind_other
}

fun QrKind.icon(): ImageVector = when (this) {
    QrKind.CONTACT -> Icons.Filled.ContactPage
    QrKind.URL -> Icons.Filled.Link
    QrKind.WIFI -> Icons.Filled.Wifi
    QrKind.PHONE -> Icons.Filled.Phone
    QrKind.EMAIL -> Icons.Filled.Email
    QrKind.SMS -> Icons.Filled.Sms
    QrKind.TEXT -> Icons.Filled.TextFields
    QrKind.OTHER -> Icons.Filled.QrCode
}

@Composable
fun HistoryScreen(
    items: List<QrResult>,
    onOpen: (QrResult) -> Unit,
    onClear: () -> Unit,
    onScan: () -> Unit,
) {
    if (items.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            EmptyState(
                Icons.Filled.History,
                stringResource(R.string.empty_history_title),
                stringResource(R.string.empty_history_desc),
            )
            Button(onClick = onScan) {
                Icon(Icons.Filled.QrCodeScanner, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.scan_now))
            }
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onClear) {
                    Icon(Icons.Filled.DeleteSweep, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.clear_history))
                }
            }
        }
        items(items, key = { it.time.toString() + it.raw.hashCode() }) { r ->
            ListItem(
                headlineContent = { Text(r.display, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(stringResource(r.kind.labelRes()) + "  •  " + formatTime(r.time)) },
                leadingContent = { Icon(r.kind.icon(), contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                modifier = Modifier.clickable { onOpen(r) },
            )
            HorizontalDivider()
        }
    }
}

@Composable
fun QrDetailScreen(result: QrResult, onSaveContact: (ContactData) -> Unit, showMessage: (String) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val copyText: (String) -> Unit = { text ->
        clipboard.setText(AnnotatedString(text))
        showMessage(context.getString(R.string.msg_copied))
    }
    val value = result.display.trim()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(result.kind.icon(), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        stringResource(result.kind.labelRes()),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                when {
                    result.kind == QrKind.CONTACT && result.contact != null -> {
                        val c = result.contact
                        InfoLine(R.string.field_name, c.name)
                        InfoLine(R.string.field_title, c.title)
                        InfoLine(R.string.field_company, c.company)
                        InfoLine(R.string.field_mobile, c.mobile)
                        InfoLine(R.string.field_phone, c.phone2)
                        InfoLine(R.string.field_email, c.email)
                        InfoLine(R.string.field_website, c.website)
                        InfoLine(R.string.field_address, c.address)
                    }
                    result.kind == QrKind.WIFI -> {
                        InfoLine(R.string.wifi_network, result.wifiSsid)
                        InfoLine(R.string.wifi_password, result.wifiPassword)
                    }
                    else -> SelectionContainer {
                        Text(value, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }

        when (result.kind) {
            QrKind.CONTACT -> PrimaryAction(Icons.Filled.PersonAdd, R.string.save_to_contacts) {
                onSaveContact(result.contact ?: ContactData(notes = result.raw))
            }
            QrKind.URL -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.link_warning), style = MaterialTheme.typography.bodySmall)
                }
                PrimaryAction(Icons.Filled.Language, R.string.open_link) {
                    val url = if (value.startsWith("http://", true) || value.startsWith("https://", true)) value else "https://$value"
                    FileActions.safeStart(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
            QrKind.PHONE -> {
                PrimaryAction(Icons.Filled.Call, R.string.call) {
                    FileActions.safeStart(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(value))))
                }
                SecondaryAction(Icons.Filled.PersonAdd, R.string.save_to_contacts) { onSaveContact(ContactData(mobile = value)) }
            }
            QrKind.EMAIL -> {
                PrimaryAction(Icons.Filled.Email, R.string.send_email) {
                    FileActions.safeStart(context, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$value")))
                }
                SecondaryAction(Icons.Filled.PersonAdd, R.string.save_to_contacts) { onSaveContact(ContactData(email = value)) }
            }
            QrKind.SMS -> PrimaryAction(Icons.Filled.Sms, R.string.send_sms) {
                FileActions.safeStart(context, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(value))))
            }
            QrKind.WIFI -> {
                if (result.wifiPassword.isNotEmpty()) {
                    PrimaryAction(Icons.Filled.Password, R.string.copy_password) { copyText(result.wifiPassword) }
                }
                SecondaryAction(Icons.Filled.Wifi, R.string.open_wifi_settings) {
                    FileActions.safeStart(context, Intent(Settings.ACTION_WIFI_SETTINGS))
                }
            }
            QrKind.TEXT, QrKind.OTHER -> Unit
        }

        SecondaryAction(Icons.Filled.ContentCopy, R.string.copy) { copyText(result.raw.ifBlank { value }) }
        SecondaryAction(Icons.Filled.Share, R.string.share) { FileActions.shareText(context, result.raw.ifBlank { value }) }
    }
}

@Composable
private fun InfoLine(@StringRes label: Int, value: String) {
    if (value.isBlank()) return
    Column {
        Text(stringResource(label), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SelectionContainer { Text(value, style = MaterialTheme.typography.bodyLarge) }
    }
}

@Composable
fun PrimaryAction(icon: ImageVector, @StringRes label: Int, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(52.dp)) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(stringResource(label))
    }
}

@Composable
fun SecondaryAction(icon: ImageVector, @StringRes label: Int, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth().height(52.dp)) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(stringResource(label))
    }
}
