@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.scansphere.app.R
import com.scansphere.app.data.FileRepository
import com.scansphere.app.util.FileActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class FileAction(@StringRes val label: Int, val icon: ImageVector) {
    OPEN(R.string.action_open, Icons.Filled.Visibility),
    SHARE(R.string.action_share, Icons.Filled.Share),
    DRIVE(R.string.action_drive, Icons.Filled.CloudUpload),
    ONEDRIVE(R.string.action_onedrive, Icons.Filled.Cloud),
    JPG(R.string.action_export_jpg, Icons.Filled.Image),
    RENAME(R.string.action_rename, Icons.Filled.DriveFileRenameOutline),
    DELETE(R.string.action_delete, Icons.Filled.Delete),
}

@Composable
fun FilesScreen(
    files: List<File>,
    repo: FileRepository,
    onChanged: () -> Unit,
    showMessage: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<File?>(null) }
    var deleteTarget by remember { mutableStateOf<File?>(null) }
    val filtered = files.filter { it.name.contains(query.trim(), ignoreCase = true) }

    fun handle(action: FileAction, file: File) {
        when (action) {
            FileAction.OPEN -> FileActions.open(context, file)
            FileAction.SHARE -> FileActions.share(context, listOf(file), "application/pdf")
            FileAction.DRIVE -> FileActions.sendToCloudApp(context, file, FileActions.DRIVE_PACKAGE, "Google Drive")
            FileAction.ONEDRIVE -> FileActions.sendToCloudApp(context, file, FileActions.ONEDRIVE_PACKAGE, "OneDrive")
            FileAction.JPG -> {
                scope.launch {
                val images = withContext(Dispatchers.IO) {
                    runCatching { FileActions.pdfToJpgs(context, file) }.getOrDefault(emptyList())
                }
                if (images.isEmpty()) {
                    showMessage(context.getString(R.string.msg_export_failed))
                } else {
                    FileActions.share(context, images, "image/jpeg")
                }
                }
            }
            FileAction.RENAME -> { renameTarget = file }
            FileAction.DELETE -> { deleteTarget = file }
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            placeholder = { Text(stringResource(R.string.search_files)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
        )
        if (filtered.isEmpty()) {
            EmptyState(
                Icons.Filled.FolderOpen,
                stringResource(R.string.empty_files_title),
                stringResource(R.string.empty_files_desc),
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(filtered, key = { it.absolutePath }) { file ->
                    FileRow(
                        file = file,
                        onClick = { FileActions.open(context, file) },
                        trailing = { FileMenu { action -> handle(action, file) } },
                    )
                    HorizontalDivider()
                }
            }
        }
    }

    renameTarget?.let { file ->
        var newName by remember(file) { mutableStateOf(file.nameWithoutExtension) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(stringResource(R.string.rename_title)) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text(stringResource(R.string.file_name)) },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = repo.rename(file, newName)
                    renameTarget = null
                    onChanged()
                    showMessage(context.getString(if (ok) R.string.msg_renamed else R.string.msg_rename_failed))
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }

    deleteTarget?.let { file ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_message, file.name)) },
            confirmButton = {
                TextButton(onClick = {
                    repo.delete(file)
                    deleteTarget = null
                    onChanged()
                    showMessage(context.getString(R.string.msg_deleted))
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun FileMenu(onAction: (FileAction) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.more_options))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            FileAction.entries.forEach { action ->
                DropdownMenuItem(
                    text = { Text(stringResource(action.label)) },
                    leadingIcon = { Icon(action.icon, contentDescription = null) },
                    onClick = {
                        expanded = false
                        onAction(action)
                    },
                )
            }
        }
    }
}
