package com.scansphere.app.ui

import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import com.scansphere.app.R
import com.scansphere.app.data.ContactData
import com.scansphere.app.util.ContactSaver
import com.scansphere.app.util.FileActions

@Composable
fun CardReviewScreen(initial: ContactData, imageUri: Uri?, onDone: () -> Unit) {
    val context = LocalContext.current
    var data by remember(initial) { mutableStateOf(initial) }
    val preview = remember(imageUri) { imageUri?.let { FileActions.loadPreview(context, it, 1280) } }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (preview != null) {
            Card(Modifier.fillMaxWidth()) {
                Image(
                    bitmap = preview.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp),
                    contentScale = ContentScale.Fit,
                )
            }
        }
        Text(
            stringResource(R.string.review_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        ContactField(R.string.field_name, data.name, Icons.Filled.Person) { data = data.copy(name = it) }
        ContactField(R.string.field_title, data.title, Icons.Filled.Work) { data = data.copy(title = it) }
        ContactField(R.string.field_company, data.company, Icons.Filled.Business) { data = data.copy(company = it) }
        ContactField(R.string.field_mobile, data.mobile, Icons.Filled.PhoneAndroid, KeyboardType.Phone) { data = data.copy(mobile = it) }
        ContactField(R.string.field_phone, data.phone2, Icons.Filled.Phone, KeyboardType.Phone) { data = data.copy(phone2 = it) }
        ContactField(R.string.field_email, data.email, Icons.Filled.Email, KeyboardType.Email) { data = data.copy(email = it) }
        ContactField(R.string.field_website, data.website, Icons.Filled.Language, KeyboardType.Uri) { data = data.copy(website = it) }
        ContactField(R.string.field_address, data.address, Icons.Filled.LocationOn, singleLine = false) { data = data.copy(address = it) }
        ContactField(R.string.field_notes, data.notes, Icons.Filled.Edit, singleLine = false) { data = data.copy(notes = it) }

        Spacer(Modifier.height(4.dp))
        Button(
            onClick = {
                ContactSaver.save(context, data)
                onDone()
            },
            enabled = data.hasAnyValue(),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Icon(Icons.Filled.PersonAdd, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.save_to_contacts))
        }
        if (data.hasAnyValue()) {
            SecondaryAction(Icons.Filled.Share, R.string.share_vcard) { ContactSaver.shareVcard(context, data) }
        }
    }
}

@Composable
private fun ContactField(
    @StringRes label: Int,
    value: String,
    icon: ImageVector,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(stringResource(label)) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        singleLine = singleLine,
        maxLines = if (singleLine) 1 else 4,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth(),
    )
}
