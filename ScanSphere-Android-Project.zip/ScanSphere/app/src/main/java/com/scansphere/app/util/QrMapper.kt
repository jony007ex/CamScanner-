package com.scansphere.app.util

import com.google.mlkit.vision.barcode.common.Barcode
import com.scansphere.app.data.ContactData
import com.scansphere.app.data.QrKind
import com.scansphere.app.data.QrResult

/** Converts an ML Kit barcode into the app's own QrResult model. */
object QrMapper {
    fun from(b: Barcode): QrResult {
        val raw = b.rawValue ?: ""
        val display = b.displayValue ?: raw
        return when (b.valueType) {
            Barcode.TYPE_CONTACT_INFO -> {
                val c = b.contactInfo
                val person = c?.name
                val fullName = person?.formattedName?.takeIf { it.isNotBlank() }
                    ?: listOfNotNull(person?.first, person?.middle, person?.last)
                        .filter { it.isNotBlank() }.joinToString(" ")
                val phones = c?.phones?.mapNotNull { it.number }?.filter { it.isNotBlank() } ?: emptyList()
                val contact = ContactData(
                    name = fullName,
                    title = c?.title ?: "",
                    company = c?.organization ?: "",
                    mobile = phones.getOrNull(0) ?: "",
                    phone2 = phones.getOrNull(1) ?: "",
                    email = c?.emails?.firstOrNull()?.address ?: "",
                    website = c?.urls?.firstOrNull() ?: "",
                    address = c?.addresses?.firstOrNull()?.addressLines?.joinToString(", ") ?: "",
                )
                QrResult(QrKind.CONTACT, raw, contact.name.ifBlank { display }, contact = contact)
            }
            Barcode.TYPE_URL -> QrResult(QrKind.URL, raw, b.url?.url ?: raw)
            Barcode.TYPE_WIFI -> {
                val ssid = b.wifi?.ssid ?: ""
                QrResult(
                    QrKind.WIFI, raw, ssid.ifBlank { display },
                    wifiSsid = ssid, wifiPassword = b.wifi?.password ?: "",
                )
            }
            Barcode.TYPE_PHONE -> QrResult(QrKind.PHONE, raw, b.phone?.number ?: display)
            Barcode.TYPE_EMAIL -> QrResult(QrKind.EMAIL, raw, b.email?.address ?: display)
            Barcode.TYPE_SMS -> QrResult(QrKind.SMS, raw, b.sms?.phoneNumber ?: display)
            Barcode.TYPE_TEXT -> QrResult(QrKind.TEXT, raw, display)
            else -> QrResult(QrKind.OTHER, raw, display)
        }
    }
}
