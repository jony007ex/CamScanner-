package com.scansphere.app.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Stores scanned PDFs in the app's private storage (files/scans). */
class FileRepository(private val context: Context) {

    private val dir: File
        get() = File(context.filesDir, "scans").apply { mkdirs() }

    fun list(): List<File> =
        dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun importPdf(uri: Uri): File? = try {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(dir, "Scan_$stamp.pdf")
        val input = context.contentResolver.openInputStream(uri)
        if (input == null) {
            null
        } else {
            input.use { inp -> out.outputStream().use { inp.copyTo(it) } }
            out
        }
    } catch (e: Exception) {
        null
    }

    fun rename(file: File, newName: String): Boolean {
        val clean = newName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (clean.isEmpty()) return false
        val finalName = if (clean.endsWith(".pdf", ignoreCase = true)) clean else "$clean.pdf"
        val target = File(dir, finalName)
        if (target.exists()) return false
        return file.renameTo(target)
    }

    fun delete(file: File): Boolean = file.delete()
}
