package com.scansphere.app.data

import android.content.Context
import org.json.JSONArray

/** Keeps the last 100 QR / barcode scans on the device. */
class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("scan_history", Context.MODE_PRIVATE)

    fun all(): List<QrResult> {
        val arr = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        return (0 until arr.length()).mapNotNull { i ->
            runCatching { QrResult.fromJson(arr.getJSONObject(i)) }.getOrNull()
        }
    }

    fun add(result: QrResult): List<QrResult> {
        val list = (listOf(result) + all()).take(100)
        save(list)
        return list
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private fun save(list: List<QrResult>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object {
        const val KEY = "items"
    }
}
