package com.scansphere.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import com.scansphere.app.ui.ScanSphereApp
import com.scansphere.app.ui.ScanSphereTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ScanSphereTheme {
                ScanSphereApp()
            }
        }
    }
}
