package com.scansphere.app.util

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.scansphere.app.data.ContactData

/** Runs on-device OCR (ML Kit) on a card image and parses the result. */
object CardRecognizer {
    fun recognize(
        context: Context,
        uri: Uri,
        onSuccess: (ContactData) -> Unit,
        onError: (Exception) -> Unit,
    ) {
        val image = try {
            InputImage.fromFilePath(context, uri)
        } catch (e: Exception) {
            onError(e)
            return
        }
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                val lines = visionText.textBlocks
                    .flatMap { block -> block.lines }
                    .map { line -> CardLine(line.text.trim(), line.boundingBox?.height() ?: 0) }
                    .filter { it.text.isNotEmpty() }
                onSuccess(CardParser.parse(lines))
            }
            .addOnFailureListener { e -> onError(e) }
            .addOnCompleteListener { recognizer.close() }
    }
}
