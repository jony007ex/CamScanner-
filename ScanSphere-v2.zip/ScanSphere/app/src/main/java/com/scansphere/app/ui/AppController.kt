package com.scansphere.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.scansphere.app.data.Category
import com.scansphere.app.data.ContactData
import com.scansphere.app.data.Doc
import com.scansphere.app.data.DocRepository
import com.scansphere.app.data.HistoryStore
import com.scansphere.app.data.QrResult
import com.scansphere.app.data.Tags
import com.scansphere.app.util.CardParser
import com.scansphere.app.util.DocxWriter
import com.scansphere.app.util.FileActions
import com.scansphere.app.util.ImageOps
import com.scansphere.app.util.Ocr
import com.scansphere.app.util.tr
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Tab { HOME, FILES, TOOLS, ME }

enum class ScanMode { DOCUMENT, ID_CARD, BOOK, WHITEBOARD, SLIDES, TIMESTAMP, BUSINESS_CARD, EXTRACT_TEXT, TRANSLATE, APPEND }

enum class PickMode { IMPORT, EXTRACT_TEXT, TRANSLATE, ID_PHOTO }

enum class DocPurpose { SIGN, WATERMARK, MERGE, EXTRACT_PAGES, REORDER, LOCK, PRINT, TO_IMAGES, LONG_IMAGE, TO_WORD, ERASE_MARKS }

enum class DocAction { SIGN, WATERMARK, EXTRACT_PAGES, REORDER, LOCK }

sealed interface Screen {
    data object Main : Screen
    data class DocView(val id: String, val start: DocAction? = null) : Screen
    data class TextResult(val title: String, val text: String, val original: String = "") : Screen
    data class CardReview(val contact: ContactData, val imagePath: String?) : Screen
    data class QrDetail(val result: QrResult) : Screen
    data object QrHistory : Screen
    data class Signature(val docId: String, val page: Int) : Screen
    data class DocPicker(val purpose: DocPurpose) : Screen
}

enum class ToolSection { SCAN, IMPORT, CONVERT, EDIT, UTILITIES }

enum class Tool(
    val section: ToolSection,
    val en: String,
    val bn: String,
    val icon: ImageVector,
    val color: Color,
    val ready: Boolean = true,
) {
    ID_CARDS(ToolSection.SCAN, "ID Cards", "আইডি কার্ড", Icons.Filled.Badge, Color(0xFF19BC9C)),
    EXTRACT_TEXT(ToolSection.SCAN, "Extract Text", "টেক্সট বের করুন", Icons.Filled.TextFields, Color(0xFF19BC9C)),
    ID_PHOTO(ToolSection.SCAN, "ID Photo Maker", "পাসপোর্ট ছবি", Icons.Filled.AccountBox, Color(0xFF4A7DFF)),
    BUSINESS_CARD(ToolSection.SCAN, "Business Card", "ভিজিটিং কার্ড", Icons.Filled.ContactPage, Color(0xFF4A7DFF)),
    TRANSLATE(ToolSection.SCAN, "Photo Translation", "ছবি অনুবাদ", Icons.Filled.Translate, Color(0xFF4A7DFF)),
    BOOK(ToolSection.SCAN, "Book", "বই", Icons.Filled.AutoStories, Color(0xFF19BC9C)),
    SLIDES(ToolSection.SCAN, "Slides", "স্লাইড", Icons.Filled.Slideshow, Color(0xFFFF6B4A)),
    WHITEBOARD(ToolSection.SCAN, "Whiteboard", "হোয়াইটবোর্ড", Icons.Filled.Gesture, Color(0xFF19BC9C)),
    TIMESTAMP(ToolSection.SCAN, "Timestamp", "টাইমস্ট্যাম্প", Icons.Filled.Schedule, Color(0xFF4A7DFF)),
    FORMULA(ToolSection.SCAN, "Formula", "ফর্মুলা", Icons.Filled.Functions, Color(0xFF19BC9C), ready = false),

    IMPORT_IMAGES(ToolSection.IMPORT, "Import Images", "ছবি ইমপোর্ট", Icons.Filled.Image, Color(0xFF19BC9C)),
    IMPORT_FILES(ToolSection.IMPORT, "Import Files", "PDF ইমপোর্ট", Icons.Filled.UploadFile, Color(0xFF4A7DFF)),

    TO_WORD(ToolSection.CONVERT, "To Word", "Word-এ রূপান্তর", Icons.Filled.Description, Color(0xFF4A7DFF)),
    PDF_TO_IMAGES(ToolSection.CONVERT, "PDF to Images", "PDF থেকে ছবি", Icons.Filled.Collections, Color(0xFF19BC9C)),
    LONG_IMAGE(ToolSection.CONVERT, "PDF to Long Image", "লম্বা ছবি", Icons.Filled.ViewDay, Color(0xFF29B6F6)),
    TO_EXCEL(ToolSection.CONVERT, "To Excel", "Excel-এ রূপান্তর", Icons.Filled.TableChart, Color(0xFF2E9E4F), ready = false),
    TO_PPT(ToolSection.CONVERT, "To PPT", "PPT-তে রূপান্তর", Icons.Filled.CastForEducation, Color(0xFFFF6B4A), ready = false),

    SIGN(ToolSection.EDIT, "Sign", "স্বাক্ষর", Icons.Filled.Create, Color(0xFF19BC9C)),
    WATERMARK(ToolSection.EDIT, "Add Watermark", "ওয়াটারমার্ক", Icons.Filled.BrandingWatermark, Color(0xFF4A7DFF)),
    ERASE_MARKS(ToolSection.EDIT, "Erase Marks", "দাগ মুছুন", Icons.Filled.FormatClear, Color(0xFF4A7DFF)),
    MERGE(ToolSection.EDIT, "Merge Files", "ফাইল একত্র", Icons.Filled.MergeType, Color(0xFF19BC9C)),
    EXTRACT_PAGES(ToolSection.EDIT, "Extract PDF Pages", "পেজ আলাদা করুন", Icons.Filled.ContentCut, Color(0xFF4A7DFF)),
    REORDER(ToolSection.EDIT, "Reorder Pages", "পেজ সাজান", Icons.Filled.SwapVert, Color(0xFF4A7DFF)),
    LOCK(ToolSection.EDIT, "Lock", "লক", Icons.Filled.Lock, Color(0xFF2E9E4F)),
    SMART_ERASE(ToolSection.EDIT, "Smart Erase", "স্মার্ট ইরেজ", Icons.Filled.AutoFixHigh, Color(0xFF19BC9C), ready = false),
    RESTORE_PHOTO(ToolSection.EDIT, "Restore Photo", "ছবি রিস্টোর", Icons.Filled.Restore, Color(0xFFFF6B4A), ready = false),

    PRINT(ToolSection.UTILITIES, "Print", "প্রিন্ট", Icons.Filled.Print, Color(0xFF19BC9C)),
    SCAN_CODE(ToolSection.UTILITIES, "Scan Code", "QR স্ক্যান", Icons.Filled.QrCodeScanner, Color(0xFF19BC9C)),
    QR_HISTORY(ToolSection.UTILITIES, "QR History", "QR হিস্ট্রি", Icons.Filled.History, Color(0xFF4A7DFF)),
    AI(ToolSection.UTILITIES, "AI Assistant", "AI সহকারী", Icons.Filled.AutoAwesome, Color(0xFF19BC9C), ready = false),
    COUNT(ToolSection.UTILITIES, "CountCam", "কাউন্টক্যাম", Icons.Filled.Calculate, Color(0xFF29B6F6), ready = false),
}

class AppController(
    val context: Context,
    private val scope: CoroutineScope,
    private val snackbar: SnackbarHostState,
) {
    val repo = DocRepository(context.applicationContext)
    private val historyStore = HistoryStore(context.applicationContext)
    private val settings = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var docs by mutableStateOf(repo.list())
    var folders by mutableStateOf(repo.folders())
    var qrHistory by mutableStateOf(historyStore.all())
    var busy by mutableStateOf<String?>(null)
    var tab by mutableStateOf(Tab.HOME)
    val stack = mutableStateListOf<Screen>(Screen.Main)
    var info by mutableStateOf<Pair<String, String>?>(null)
    var pinPrompt by mutableStateOf<Doc?>(null)
    var idPhotoDialog by mutableStateOf(false)
    var userName by mutableStateOf(settings.getString("user", "") ?: "")
    var prefix by mutableStateOf(settings.getString("prefix", "ScanSphere") ?: "ScanSphere")

    // Set by the composable that owns the activity-result launchers.
    var startScan: (ScanMode) -> Unit = {}
    var pickImages: (PickMode) -> Unit = {}
    var pickPdf: () -> Unit = {}
    var scanQr: () -> Unit = {}

    var appendTarget: String = ""
    var idPhotoSize: Pair<Float, Float> = Pair(40f, 50f)

    // ---------- Navigation & state ----------

    fun refresh() {
        docs = repo.list()
        folders = repo.folders()
    }

    fun doc(id: String): Doc? = docs.firstOrNull { it.id == id }

    fun push(s: Screen) {
        stack.add(s)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun replaceTop(s: Screen) {
        stack[stack.lastIndex] = s
    }

    fun toast(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun work(message: String, block: suspend () -> Unit) {
        scope.launch {
            busy = message
            try {
                block()
            } catch (e: Exception) {
                toast(tr("Something went wrong. ", "সমস্যা হয়েছে। ") + (e.message ?: ""))
            } finally {
                busy = null
            }
        }
    }

    suspend fun <T> io(block: suspend () -> T): T = withContext(Dispatchers.IO) { block() }

    fun setUser(name: String) {
        userName = name.trim()
        settings.edit().putString("user", userName).apply()
    }

    fun setPrefixName(p: String) {
        prefix = p.trim().ifBlank { "ScanSphere" }
        settings.edit().putString("prefix", prefix).apply()
    }

    fun newName(kind: String = ""): String = repo.defaultName(if (kind.isEmpty()) prefix else "$prefix $kind")

    fun openDoc(doc: Doc) {
        if (doc.locked) pinPrompt = doc else push(Screen.DocView(doc.id))
    }

    fun addQr(result: QrResult) {
        qrHistory = historyStore.add(result)
        push(Screen.QrDetail(result))
    }

    fun clearQrHistory() {
        historyStore.clear()
        qrHistory = emptyList()
    }

    private val processing get() = tr("Processing...", "প্রসেস হচ্ছে...")

    // ---------- Scan & import results ----------

    fun handleScan(mode: ScanMode, uris: List<Uri>) {
        work(processing) {
            when (mode) {
                ScanMode.EXTRACT_TEXT, ScanMode.TRANSLATE -> {
                    val text = io { Ocr.textOfUris(context, uris) }
                    showText(mode == ScanMode.TRANSLATE, text)
                }
                ScanMode.BUSINESS_CARD -> {
                    val doc = io { repo.importUris(uris, newName("Card"), Category.CARD, listOf(Tags.BUSINESS_CARD)) }
                    refresh()
                    val file = repo.pageFiles(doc).firstOrNull()
                    val lines = if (file != null) io { Ocr.cardLines(file) } else emptyList()
                    push(Screen.CardReview(CardParser.parse(lines), file?.path))
                }
                ScanMode.APPEND -> {
                    val target = repo.load(appendTarget)
                    if (target != null) io { repo.appendUris(target, uris) }
                    refresh()
                }
                ScanMode.ID_CARD -> {
                    val doc = io {
                        val cards = uris.mapNotNull { ImageOps.decodeUri(context, it, 2000) }
                        repo.createFromBitmaps(newName("ID"), Category.ID, listOf(Tags.ID_CARD), listOf(ImageOps.idCardSheet(cards)))
                    }
                    refresh()
                    push(Screen.DocView(doc.id))
                }
                else -> {
                    val stampText = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())
                    val doc = io {
                        when (mode) {
                            ScanMode.BOOK -> repo.importUris(uris, newName("Book"), Category.SCAN, listOf(Tags.BOOK)) { ImageOps.splitBook(it) }
                            ScanMode.WHITEBOARD -> repo.importUris(uris, newName("Whiteboard"), Category.SCAN, listOf(Tags.WHITEBOARD)) { listOf(ImageOps.enhance(it)) }
                            ScanMode.SLIDES -> repo.importUris(uris, newName("Slides"), Category.SCAN, listOf(Tags.PPT))
                            ScanMode.TIMESTAMP -> repo.importUris(uris, newName(), Category.SCAN, emptyList()) { listOf(ImageOps.stamp(it, stampText)) }
                            else -> repo.importUris(uris, newName(), Category.SCAN, emptyList())
                        }
                    }
                    refresh()
                    push(Screen.DocView(doc.id))
                }
            }
        }
    }

    fun handlePick(mode: PickMode, uris: List<Uri>) {
        work(processing) {
            when (mode) {
                PickMode.IMPORT -> {
                    val doc = io { repo.importUris(uris, newName(), Category.SCAN, emptyList()) }
                    refresh()
                    push(Screen.DocView(doc.id))
                }
                PickMode.EXTRACT_TEXT, PickMode.TRANSLATE -> {
                    val text = io { Ocr.textOfUris(context, uris) }
                    showText(mode == PickMode.TRANSLATE, text)
                }
                PickMode.ID_PHOTO -> {
                    val size = idPhotoSize
                    val doc = io {
                        val photo = ImageOps.decodeUri(context, uris.first(), 2400)
                            ?: throw IllegalStateException(tr("Could not open the photo", "ছবি খোলা যায়নি"))
                        repo.createFromBitmaps(newName("Photo"), Category.PHOTO, emptyList(), listOf(ImageOps.idPhotoSheet(photo, size.first, size.second)))
                    }
                    refresh()
                    push(Screen.DocView(doc.id))
                }
            }
        }
    }

    fun handlePdf(uri: Uri) {
        work(processing) {
            val doc = io { repo.importPdf(uri) }
            refresh()
            if (doc == null) {
                toast(tr("Could not open this PDF (it may be password protected)", "PDF খোলা যায়নি (পাসওয়ার্ড দেওয়া থাকতে পারে)"))
            } else {
                push(Screen.DocView(doc.id))
            }
        }
    }

    private suspend fun showText(translate: Boolean, text: String) {
        if (text.isBlank()) {
            toast(tr("No text found. Try again in better light.", "কোনো লেখা পাওয়া যায়নি। ভালো আলোতে আবার চেষ্টা করুন।"))
            return
        }
        if (translate) {
            busy = tr("Translating (first time downloads the language)...", "অনুবাদ হচ্ছে (প্রথমবার ভাষা ডাউনলোড হবে)...")
            val out = io { Ocr.translateToBangla(text) }
            push(Screen.TextResult(tr("Translation", "অনুবাদ"), out, original = text))
        } else {
            push(Screen.TextResult(tr("Extracted text", "বের করা লেখা"), text))
        }
    }

    // ---------- Document actions ----------

    fun sharePdf(doc: Doc) = work(tr("Creating PDF...", "PDF তৈরি হচ্ছে...")) {
        val pdf = io { repo.buildPdf(doc) }
        FileActions.share(context, listOf(pdf), "application/pdf")
    }

    fun sharePdfs(list: List<Doc>) = work(tr("Creating PDF...", "PDF তৈরি হচ্ছে...")) {
        val files = io { list.map { repo.buildPdf(it) } }
        FileActions.share(context, files, "application/pdf")
    }

    fun viewPdf(doc: Doc) = work(tr("Creating PDF...", "PDF তৈরি হচ্ছে...")) {
        val pdf = io { repo.buildPdf(doc) }
        FileActions.open(context, pdf, "application/pdf")
    }

    fun toCloud(doc: Doc, google: Boolean) = work(tr("Creating PDF...", "PDF তৈরি হচ্ছে...")) {
        val pdf = io { repo.buildPdf(doc) }
        if (google) {
            FileActions.sendToCloudApp(context, pdf, "application/pdf", FileActions.DRIVE_PACKAGE, "Google Drive")
        } else {
            FileActions.sendToCloudApp(context, pdf, "application/pdf", FileActions.ONEDRIVE_PACKAGE, "OneDrive")
        }
    }

    fun printDoc(doc: Doc) = work(tr("Preparing to print...", "প্রিন্টের প্রস্তুতি...")) {
        val pdf = io { repo.buildPdf(doc) }
        FileActions.print(context, pdf, repo.safeName(doc.name))
    }

    fun shareImages(doc: Doc) = work(processing) {
        val files = io { repo.exportImages(doc) }
        FileActions.share(context, files, "image/jpeg")
    }

    fun shareLongImage(doc: Doc) = work(processing) {
        val file = io {
            val bmp = ImageOps.longImage(repo.pageFiles(doc)) ?: throw IllegalStateException("empty")
            val out = File(repo.exportDir(), repo.safeName(doc.name) + "_long.jpg")
            ImageOps.saveJpeg(bmp, out, 88)
            bmp.recycle()
            out
        }
        FileActions.share(context, listOf(file), "image/jpeg")
    }

    fun extractText(doc: Doc, translate: Boolean = false) = work(tr("Reading text...", "লেখা পড়া হচ্ছে...")) {
        val text = io { Ocr.textOfFiles(repo.pageFiles(doc)) }
        showText(translate, text)
    }

    fun toWord(doc: Doc) = work(tr("Converting to Word...", "Word-এ রূপান্তর হচ্ছে...")) {
        val text = io { Ocr.textOfFiles(repo.pageFiles(doc)) }
        if (text.isBlank()) {
            toast(tr("No text found in this file", "এই ফাইলে কোনো লেখা পাওয়া যায়নি"))
        } else {
            shareWordNow(text, doc.name)
        }
    }

    private suspend fun shareWordNow(text: String, name: String) {
        val out = io {
            val f = File(repo.exportDir(), repo.safeName(name) + ".docx")
            DocxWriter.write(text, f)
            f
        }
        FileActions.share(context, listOf(out), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    }

    fun shareWord(text: String, name: String) = work(processing) { shareWordNow(text, name) }

    fun shareTxt(text: String, name: String) = work(processing) {
        val out = io {
            val f = File(repo.exportDir(), repo.safeName(name) + ".txt")
            f.writeText(text)
            f
        }
        FileActions.share(context, listOf(out), "text/plain")
    }

    fun translateText(text: String) = work(tr("Translating...", "অনুবাদ হচ্ছে...")) {
        showText(true, text)
    }

    fun merge(list: List<Doc>) = work(tr("Merging...", "একত্র করা হচ্ছে...")) {
        val doc = io { repo.merge(list, newName("Merged")) }
        refresh()
        push(Screen.DocView(doc.id))
    }

    fun deleteDocs(list: List<Doc>) {
        list.forEach { repo.delete(it) }
        refresh()
        toast(tr("Deleted", "ডিলিট হয়েছে"))
    }

    fun handlePurpose(p: DocPurpose, doc: Doc) {
        when (p) {
            DocPurpose.SIGN -> replaceTop(Screen.DocView(doc.id, DocAction.SIGN))
            DocPurpose.WATERMARK -> replaceTop(Screen.DocView(doc.id, DocAction.WATERMARK))
            DocPurpose.EXTRACT_PAGES -> replaceTop(Screen.DocView(doc.id, DocAction.EXTRACT_PAGES))
            DocPurpose.REORDER -> replaceTop(Screen.DocView(doc.id, DocAction.REORDER))
            DocPurpose.LOCK -> replaceTop(Screen.DocView(doc.id, DocAction.LOCK))
            DocPurpose.PRINT -> { pop(); printDoc(doc) }
            DocPurpose.TO_IMAGES -> { pop(); shareImages(doc) }
            DocPurpose.LONG_IMAGE -> { pop(); shareLongImage(doc) }
            DocPurpose.TO_WORD -> { pop(); toWord(doc) }
            DocPurpose.ERASE_MARKS -> {
                replaceTop(Screen.DocView(doc.id))
                work(processing) {
                    io { repo.transformPages(doc, doc.pages.indices.toList()) { ImageOps.eraseMarks(it) } }
                    refresh()
                }
            }
            DocPurpose.MERGE -> Unit
        }
    }

    fun onTool(t: Tool) {
        if (!t.ready) {
            info = Pair(
                tr(t.en, t.bn),
                tr(
                    "This feature needs an online AI service and will come in a later version.",
                    "এই ফিচারের জন্য অনলাইন AI সার্ভিস লাগে। পরের ভার্সনে যোগ হবে।"
                )
            )
            return
        }
        when (t) {
            Tool.ID_CARDS -> startScan(ScanMode.ID_CARD)
            Tool.EXTRACT_TEXT -> startScan(ScanMode.EXTRACT_TEXT)
            Tool.ID_PHOTO -> idPhotoDialog = true
            Tool.BUSINESS_CARD -> startScan(ScanMode.BUSINESS_CARD)
            Tool.TRANSLATE -> startScan(ScanMode.TRANSLATE)
            Tool.BOOK -> startScan(ScanMode.BOOK)
            Tool.SLIDES -> startScan(ScanMode.SLIDES)
            Tool.WHITEBOARD -> startScan(ScanMode.WHITEBOARD)
            Tool.TIMESTAMP -> startScan(ScanMode.TIMESTAMP)
            Tool.IMPORT_IMAGES -> pickImages(PickMode.IMPORT)
            Tool.IMPORT_FILES -> pickPdf()
            Tool.TO_WORD -> pickDoc(DocPurpose.TO_WORD)
            Tool.PDF_TO_IMAGES -> pickDoc(DocPurpose.TO_IMAGES)
            Tool.LONG_IMAGE -> pickDoc(DocPurpose.LONG_IMAGE)
            Tool.SIGN -> pickDoc(DocPurpose.SIGN)
            Tool.WATERMARK -> pickDoc(DocPurpose.WATERMARK)
            Tool.ERASE_MARKS -> pickDoc(DocPurpose.ERASE_MARKS)
            Tool.MERGE -> pickDoc(DocPurpose.MERGE)
            Tool.EXTRACT_PAGES -> pickDoc(DocPurpose.EXTRACT_PAGES)
            Tool.REORDER -> pickDoc(DocPurpose.REORDER)
            Tool.LOCK -> pickDoc(DocPurpose.LOCK)
            Tool.PRINT -> pickDoc(DocPurpose.PRINT)
            Tool.SCAN_CODE -> scanQr()
            Tool.QR_HISTORY -> push(Screen.QrHistory)
            else -> Unit
        }
    }

    private fun pickDoc(p: DocPurpose) {
        if (docs.isEmpty()) {
            toast(tr("Scan or import a file first", "আগে কোনো ফাইল স্ক্যান বা ইমপোর্ট করুন"))
        } else {
            push(Screen.DocPicker(p))
        }
    }

    fun sendFeedback() {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_SUBJECT, "ScanSphere feedback")
        FileActions.safeStart(context, intent)
    }

    fun recommend() {
        FileActions.shareText(
            context,
            tr("Try ScanSphere: scan documents, visiting cards and QR codes in one app.",
                "ScanSphere ব্যবহার করে দেখুন: ডকুমেন্ট, ভিজিটিং কার্ড আর QR কোড স্ক্যান, সব এক অ্যাপে।")
        )
    }
}
