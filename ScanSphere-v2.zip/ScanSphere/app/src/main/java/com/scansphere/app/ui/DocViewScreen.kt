@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.scansphere.app.data.Tags
import com.scansphere.app.util.ImageOps
import com.scansphere.app.util.tr

private enum class PageMode { NORMAL, REORDER, EXTRACT }

@Composable
fun DocViewScreen(c: AppController, id: String, start: DocAction?) {
    val doc = c.doc(id)
    if (doc == null) {
        EmptyState(Icons.Filled.ErrorOutline, tr("File not found", "ফাইল পাওয়া যায়নি"), "")
        return
    }
    val pages = c.repo.pageFiles(doc)
    var sel by remember { mutableIntStateOf(0) }
    val index = if (pages.isEmpty()) 0 else sel.coerceIn(0, pages.size - 1)
    var mode by remember { mutableStateOf(PageMode.NORMAL) }
    var picked by remember { mutableStateOf(setOf<Int>()) }
    var dialog by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(start) {
        if (start != null) {
            c.replaceTop(Screen.DocView(id))
            when (start) {
                DocAction.SIGN -> c.push(Screen.Signature(id, index))
                DocAction.WATERMARK -> dialog = "watermark"
                DocAction.LOCK -> dialog = "lock"
                DocAction.REORDER -> mode = PageMode.REORDER
                DocAction.EXTRACT_PAGES -> mode = PageMode.EXTRACT
            }
        }
    }

    fun edit(all: Boolean, label: String, f: (android.graphics.Bitmap) -> android.graphics.Bitmap) {
        c.work(label) {
            val targets = if (all) doc.pages.indices.toList() else listOf(index)
            c.io { c.repo.transformPages(doc, targets, f) }
            c.refresh()
        }
    }

    Column(Modifier.fillMaxSize()) {
        // ---------- Big preview ----------
        Box(
            Modifier.weight(1f).fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
        ) {
            if (pages.isEmpty()) {
                Text(tr("No pages", "কোনো পেজ নেই"))
            } else {
                FileImage(pages[index], 1800, Modifier.fillMaxSize().padding(12.dp), ContentScale.Fit)
                Text(
                    "${index + 1} / ${pages.size}",
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                )
            }
        }

        // ---------- Thumbnails ----------
        LazyRow(
            state = listState,
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(pages, key = { _, f -> f.name }) { i, f ->
                val isSel = i == index
                Box(
                    Modifier
                        .size(width = 62.dp, height = 84.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .border(
                            width = if (isSel) 2.dp else 0.dp,
                            color = if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                        )
                        .clickable {
                            if (mode == PageMode.EXTRACT) {
                                picked = if (i in picked) picked - i else picked + i
                            } else {
                                sel = i
                            }
                        },
                ) {
                    FileImage(f, 240, Modifier.fillMaxSize())
                    Text(
                        "${i + 1}",
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.align(Alignment.BottomStart).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 4.dp),
                    )
                    if (mode == PageMode.EXTRACT) {
                        Checkbox(checked = i in picked, onCheckedChange = { picked = if (i in picked) picked - i else picked + i }, modifier = Modifier.align(Alignment.TopEnd))
                    }
                }
            }
        }

        // ---------- Bottom bar ----------
        Surface(tonalElevation = 4.dp) {
            when (mode) {
                PageMode.REORDER -> Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        if (index > 0) {
                            c.repo.movePage(doc, index, index - 1)
                            sel = index - 1
                            c.refresh()
                        }
                    }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.ChevronLeft, null); Text(tr("Earlier", "আগে")) }
                    OutlinedButton(onClick = {
                        if (index < pages.size - 1) {
                            c.repo.movePage(doc, index, index + 1)
                            sel = index + 1
                            c.refresh()
                        }
                    }, modifier = Modifier.weight(1f)) { Text(tr("Later", "পরে")); Icon(Icons.Filled.ChevronRight, null) }
                    Button(onClick = { mode = PageMode.NORMAL }) { Text(tr("Done", "শেষ")) }
                }
                PageMode.EXTRACT -> Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { mode = PageMode.NORMAL; picked = emptySet() }, modifier = Modifier.weight(1f)) { Text(tr("Cancel", "বাতিল")) }
                    Button(onClick = {
                        if (picked.isEmpty()) {
                            c.toast(tr("Tap pages to select them", "পেজে ট্যাপ করে বাছাই করুন"))
                        } else {
                            val chosen = picked.toList()
                            mode = PageMode.NORMAL
                            picked = emptySet()
                            c.work(tr("Creating file...", "ফাইল তৈরি হচ্ছে...")) {
                                val nd = c.io { c.repo.extractPages(doc, chosen, doc.name + " (" + chosen.size + ")") }
                                c.refresh()
                                c.push(Screen.DocView(nd.id))
                            }
                        }
                    }, modifier = Modifier.weight(1f)) { Text(tr("New file", "নতুন ফাইল") + " (" + picked.size + ")") }
                }
                PageMode.NORMAL -> LazyRow(contentPadding = PaddingValues(horizontal = 4.dp)) {
                    item { ActionItem(Icons.Filled.Share, tr("Share PDF", "PDF শেয়ার")) { c.sharePdf(doc) } }
                    item { ActionItem(Icons.Filled.Visibility, tr("Open PDF", "PDF দেখুন")) { c.viewPdf(doc) } }
                    item { ActionItem(Icons.Filled.CloudUpload, "Google Drive") { c.toCloud(doc, google = true) } }
                    item { ActionItem(Icons.Filled.Cloud, "OneDrive") { c.toCloud(doc, google = false) } }
                    item {
                        ActionItem(Icons.Filled.AddAPhoto, tr("Add page", "পেজ যোগ")) {
                            c.appendTarget = doc.id
                            c.startScan(ScanMode.APPEND)
                        }
                    }
                    item { ActionItem(Icons.Filled.Tune, tr("Filters", "ফিল্টার")) { dialog = "filter" } }
                    item { ActionItem(Icons.Filled.RotateRight, tr("Rotate", "ঘোরান")) { edit(false, tr("Rotating...", "ঘোরানো হচ্ছে...")) { ImageOps.rotate(it, 90f) } } }
                    item { ActionItem(Icons.Filled.Create, tr("Sign", "স্বাক্ষর")) { c.push(Screen.Signature(doc.id, index)) } }
                    item { ActionItem(Icons.Filled.BrandingWatermark, tr("Watermark", "ওয়াটারমার্ক")) { dialog = "watermark" } }
                    item { ActionItem(Icons.Filled.TextFields, tr("Extract text", "লেখা বের")) { c.extractText(doc) } }
                    item { ActionItem(Icons.Filled.Translate, tr("Translate", "অনুবাদ")) { c.extractText(doc, translate = true) } }
                    item { ActionItem(Icons.Filled.Description, tr("To Word", "Word")) { c.toWord(doc) } }
                    item { ActionItem(Icons.Filled.Collections, tr("To images", "ছবি (JPG)")) { c.shareImages(doc) } }
                    item { ActionItem(Icons.Filled.ViewDay, tr("Long image", "লম্বা ছবি")) { c.shareLongImage(doc) } }
                    item { ActionItem(Icons.Filled.SwapVert, tr("Reorder", "পেজ সাজান")) { mode = PageMode.REORDER } }
                    item { ActionItem(Icons.Filled.ContentCut, tr("Extract pages", "পেজ আলাদা")) { mode = PageMode.EXTRACT } }
                    item { ActionItem(Icons.Filled.DeleteSweep, tr("Delete page", "পেজ ডিলিট")) { dialog = "deletePage" } }
                    item { ActionItem(Icons.Filled.Print, tr("Print", "প্রিন্ট")) { c.printDoc(doc) } }
                    item { ActionItem(Icons.Filled.Bookmark, tr("Tags", "ট্যাগ")) { dialog = "tags" } }
                    item { ActionItem(Icons.Filled.Folder, tr("Folder", "ফোল্ডার")) { dialog = "folder" } }
                    item { ActionItem(if (doc.locked) Icons.Filled.LockOpen else Icons.Filled.Lock, if (doc.locked) tr("Unlock", "আনলক") else tr("Lock", "লক")) { dialog = "lock" } }
                    item { ActionItem(Icons.Filled.Edit, tr("Rename", "নাম বদল")) { dialog = "rename" } }
                    item { ActionItem(Icons.Filled.Delete, tr("Delete file", "ফাইল ডিলিট")) { dialog = "deleteDoc" } }
                }
            }
        }
    }

    // ---------- Dialogs ----------
    when (dialog) {
        "watermark" -> InputDialog(tr("Add watermark", "ওয়াটারমার্ক যোগ করুন"), "CONFIDENTIAL", tr("Watermark text", "ওয়াটারমার্কের লেখা"),
            onDismiss = { dialog = "" }) { text ->
            dialog = ""
            if (text.isNotBlank()) edit(true, tr("Adding watermark...", "ওয়াটারমার্ক যোগ হচ্ছে...")) { ImageOps.watermark(it, text.trim()) }
        }
        "rename" -> InputDialog(tr("Rename", "নাম বদলান"), doc.name, tr("File name", "ফাইলের নাম"), onDismiss = { dialog = "" }) {
            c.repo.rename(doc, it)
            c.refresh()
            dialog = ""
        }
        "lock" -> if (doc.locked) {
            ConfirmDialog(tr("Remove lock?", "লক সরাবেন?"), tr("Anyone using this phone will be able to open the file.", "এই ফোন থেকে যে কেউ ফাইলটা খুলতে পারবে।"),
                tr("Unlock", "আনলক"), onDismiss = { dialog = "" }) {
                c.repo.setPin(doc, "")
                c.refresh()
                dialog = ""
            }
        } else {
            InputDialog(tr("Set a 4-digit PIN", "৪ সংখ্যার PIN দিন"), "", "PIN", KeyboardType.NumberPassword, isPassword = true, onDismiss = { dialog = "" }) {
                if (it.length < 4 || !it.all { ch -> ch.isDigit() }) {
                    c.toast(tr("PIN must be at least 4 digits", "PIN কমপক্ষে ৪ সংখ্যার হতে হবে"))
                } else {
                    c.repo.setPin(doc, it)
                    c.refresh()
                    c.toast(tr("File locked", "ফাইল লক হয়েছে"))
                    dialog = ""
                }
            }
        }
        "deletePage" -> ConfirmDialog(tr("Delete this page?", "এই পেজ ডিলিট করবেন?"), tr("Page ${index + 1} will be removed.", "${index + 1} নম্বর পেজ মুছে যাবে।"),
            tr("Delete", "ডিলিট"), onDismiss = { dialog = "" }) {
            c.repo.deletePage(doc, index)
            sel = (index - 1).coerceAtLeast(0)
            c.refresh()
            dialog = ""
        }
        "deleteDoc" -> ConfirmDialog(tr("Delete file?", "ফাইল ডিলিট করবেন?"), doc.name, tr("Delete", "ডিলিট"), onDismiss = { dialog = "" }) {
            dialog = ""
            c.pop()
            c.deleteDocs(listOf(doc))
        }
        "filter" -> FilterDialog(onDismiss = { dialog = "" }) { name, all ->
            dialog = ""
            val f: (android.graphics.Bitmap) -> android.graphics.Bitmap = when (name) {
                "enhance" -> ImageOps::enhance
                "gray" -> ImageOps::grayscale
                "bw" -> ImageOps::blackWhite
                else -> ImageOps::eraseMarks
            }
            edit(all, tr("Applying filter...", "ফিল্টার দেওয়া হচ্ছে..."), f)
        }
        "tags" -> {
            var chosen by remember { mutableStateOf(doc.tags.toSet()) }
            AlertDialog(
                onDismissRequest = { dialog = "" },
                title = { Text(tr("Tags", "ট্যাগ")) },
                text = {
                    Column {
                        Tags.ALL.forEach { t ->
                            Row(
                                Modifier.fillMaxWidth().clickable { chosen = if (t in chosen) chosen - t else chosen + t },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Checkbox(checked = t in chosen, onCheckedChange = { chosen = if (t in chosen) chosen - t else chosen + t })
                                Text(t)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        c.repo.setTags(doc, chosen.toList())
                        c.refresh()
                        dialog = ""
                    }) { Text(tr("Save", "সেভ")) }
                },
                dismissButton = { TextButton(onClick = { dialog = "" }) { Text(tr("Cancel", "বাতিল")) } },
            )
        }
        "folder" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(tr("Move to folder", "ফোল্ডারে সরান")) },
            text = {
                Column {
                    if (c.folders.isEmpty()) Text(tr("Create a folder from the Files tab first.", "আগে Files ট্যাব থেকে ফোল্ডার তৈরি করুন।"))
                    (listOf("") + c.folders).forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                c.repo.setFolder(doc, f)
                                c.refresh()
                                dialog = ""
                            }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = doc.folder == f, onClick = null)
                            Spacer(Modifier.width(10.dp))
                            Text(if (f.isEmpty()) tr("No folder", "কোনো ফোল্ডার না") else f)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text(tr("Close", "বন্ধ")) } },
        )
        else -> Unit
    }
}

@Composable
private fun FilterDialog(onDismiss: () -> Unit, onApply: (String, Boolean) -> Unit) {
    var all by remember { mutableStateOf(false) }
    val options = listOf(
        "enhance" to tr("Auto enhance (Magic Color)", "অটো এনহ্যান্স (ম্যাজিক কালার)"),
        "gray" to tr("Grayscale", "গ্রেস্কেল"),
        "bw" to tr("Black & White", "সাদা-কালো"),
        "erase" to tr("Erase marks / remove shadow", "দাগ ও ছায়া মুছুন"),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Filters", "ফিল্টার")) },
        text = {
            Column {
                options.forEach { (key, label) ->
                    Text(label, Modifier.fillMaxWidth().clickable { onApply(key, all) }.padding(vertical = 12.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                    Switch(checked = all, onCheckedChange = { all = it })
                    Spacer(Modifier.width(10.dp))
                    Text(tr("Apply to all pages", "সব পেজে প্রয়োগ"))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Close", "বন্ধ")) } },
    )
}
