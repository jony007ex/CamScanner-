@file:OptIn(ExperimentalMaterial3Api::class)

package com.scansphere.app.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.scansphere.app.util.QrMapper
import com.scansphere.app.util.findActivity
import com.scansphere.app.util.tr

private fun Tab.icon(): ImageVector = when (this) {
    Tab.HOME -> Icons.Filled.Home
    Tab.FILES -> Icons.Filled.Description
    Tab.TOOLS -> Icons.Filled.Apps
    Tab.ME -> Icons.Filled.Person
}

private fun Tab.label(): String = when (this) {
    Tab.HOME -> tr("Home", "হোম")
    Tab.FILES -> tr("Files", "ফাইল")
    Tab.TOOLS -> tr("Tools", "টুলস")
    Tab.ME -> tr("Me", "আমি")
}

@Composable
fun ScanSphereApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val c = remember { AppController(context, scope, snackbar) }

    var pendingScan by rememberSaveable { mutableStateOf(ScanMode.DOCUMENT.name) }
    var pendingPick by rememberSaveable { mutableStateOf(PickMode.IMPORT.name) }

    // ---------- Activity result launchers ----------
    val scanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val result = GmsDocumentScanningResult.fromActivityResultIntent(res.data)
            val uris = result?.pages?.map { it.imageUri } ?: emptyList()
            if (uris.isNotEmpty()) c.handleScan(ScanMode.valueOf(pendingScan), uris)
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) c.handlePick(PickMode.valueOf(pendingPick), uris)
    }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) c.handlePdf(uri)
    }

    c.startScan = { mode ->
        pendingScan = mode.name
        val activity = context.findActivity()
        if (activity == null) {
            c.toast(tr("Scanner is not available", "স্ক্যানার চালু করা যাচ্ছে না"))
        } else {
            val limit = when (mode) {
                ScanMode.ID_CARD -> 2
                ScanMode.BUSINESS_CARD -> 1
                ScanMode.EXTRACT_TEXT, ScanMode.TRANSLATE -> 10
                else -> 100
            }
            val options = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(limit)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
            if (mode == ScanMode.ID_CARD) c.toast(tr("Scan the front, then the back", "প্রথমে সামনের দিক, তারপর পেছনের দিক স্ক্যান করুন"))
            GmsDocumentScanning.getClient(options)
                .getStartScanIntent(activity)
                .addOnSuccessListener { sender -> scanLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
                .addOnFailureListener {
                    c.toast(tr("Scanner could not start. Update Google Play services.", "স্ক্যানার চালু হয়নি। Google Play services আপডেট করুন।"))
                }
        }
    }
    c.pickImages = { mode ->
        pendingPick = mode.name
        imagePicker.launch("image/*")
    }
    c.pickPdf = { pdfPicker.launch(arrayOf("application/pdf")) }
    c.scanQr = {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .enableAutoZoom()
            .build()
        GmsBarcodeScanning.getClient(context, options)
            .startScan()
            .addOnSuccessListener { c.addQr(QrMapper.from(it)) }
            .addOnFailureListener {
                c.toast(tr("QR scanner could not start", "QR স্ক্যানার চালু হয়নি"))
            }
    }

    val current = c.stack.last()
    BackHandler(enabled = c.stack.size > 1 || c.tab != Tab.HOME) {
        if (c.stack.size > 1) {
            c.pop()
        } else {
            c.tab = Tab.HOME
        }
    }

    val title = when (current) {
        is Screen.DocView -> c.doc(current.id)?.name ?: ""
        is Screen.TextResult -> current.title
        is Screen.CardReview -> tr("Review contact", "কন্টাক্ট যাচাই")
        is Screen.QrDetail -> tr("Scan result", "স্ক্যানের ফলাফল")
        Screen.QrHistory -> tr("QR history", "QR হিস্ট্রি")
        is Screen.Signature -> tr("Sign", "স্বাক্ষর")
        is Screen.DocPicker -> tr("Select file", "ফাইল বাছুন")
        Screen.Main -> c.tab.label()
    }

    Scaffold(
        topBar = {
            if (current !is Screen.Main) {
                TopAppBar(
                    title = { Text(title, maxLines = 1) },
                    navigationIcon = {
                        IconButton(onClick = { c.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Back", "পেছনে")) }
                    },
                )
            } else if (c.tab == Tab.TOOLS || c.tab == Tab.FILES) {
                TopAppBar(title = { Text(title, fontWeight = FontWeight.SemiBold) })
            }
        },
        bottomBar = {
            if (current is Screen.Main) {
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = c.tab == t,
                            onClick = { c.tab = t },
                            icon = { Icon(t.icon(), null) },
                            label = { Text(t.label()) },
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (current is Screen.Main && (c.tab == Tab.HOME || c.tab == Tab.FILES)) {
                FloatingActionButton(
                    onClick = { c.startScan(ScanMode.DOCUMENT) },
                    containerColor = Teal,
                    contentColor = Color.White,
                    shape = androidx.compose.foundation.shape.CircleShape,
                ) { Icon(Icons.Filled.PhotoCamera, tr("Scan", "স্ক্যান")) }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (current) {
                Screen.Main -> when (c.tab) {
                    Tab.HOME -> HomeScreen(c)
                    Tab.FILES -> FilesScreen(c)
                    Tab.TOOLS -> ToolsScreen(c)
                    Tab.ME -> MeScreen(c)
                }
                is Screen.DocView -> DocViewScreen(c, current.id, current.start)
                is Screen.TextResult -> TextResultScreen(c, current.title, current.text, current.original)
                is Screen.CardReview -> CardReviewScreen(c, current.contact, current.imagePath)
                is Screen.QrDetail -> QrDetailScreen(c, current.result)
                Screen.QrHistory -> QrHistoryScreen(c)
                is Screen.Signature -> SignatureScreen(c, current.docId, current.page)
                is Screen.DocPicker -> DocPickerScreen(c, current.purpose)
            }

            val busy = c.busy
            if (busy != null) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {},
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(color = Teal)
                        Text(busy, color = Color.White)
                    }
                }
            }
        }
    }

    // ---------- Global dialogs ----------
    val info = c.info
    if (info != null) {
        AlertDialog(
            onDismissRequest = { c.info = null },
            title = { Text(info.first) },
            text = { Text(info.second) },
            confirmButton = { TextButton(onClick = { c.info = null }) { Text(tr("OK", "ঠিক আছে")) } },
        )
    }

    val locked = c.pinPrompt
    if (locked != null) {
        InputDialog(
            tr("Enter PIN", "PIN দিন"), "", "PIN", KeyboardType.NumberPassword, isPassword = true,
            onDismiss = { c.pinPrompt = null },
        ) { pin ->
            if (c.repo.checkPin(locked, pin)) {
                c.pinPrompt = null
                c.push(Screen.DocView(locked.id))
            } else {
                c.toast(tr("Wrong PIN", "ভুল PIN"))
            }
        }
    }

    if (c.idPhotoDialog) {
        AlertDialog(
            onDismissRequest = { c.idPhotoDialog = false },
            title = { Text(tr("Photo size", "ছবির মাপ")) },
            text = {
                Column {
                    listOf(
                        Triple(40f, 50f, tr("Bangladesh passport (40 × 50 mm)", "বাংলাদেশি পাসপোর্ট (40 × 50 mm)")),
                        Triple(35f, 45f, tr("Visa / stamp (35 × 45 mm)", "ভিসা / স্ট্যাম্প (35 × 45 mm)")),
                        Triple(51f, 51f, tr("US visa (2 × 2 inch)", "US ভিসা (2 × 2 ইঞ্চি)")),
                    ).forEach { (w, h, label) ->
                        Text(
                            label,
                            Modifier.fillMaxWidth().clickable {
                                c.idPhotoSize = Pair(w, h)
                                c.idPhotoDialog = false
                                c.pickImages(PickMode.ID_PHOTO)
                            }.padding(vertical = 12.dp),
                        )
                    }
                    Text(
                        tr("Pick a clear front-facing photo. A 4×6 inch print sheet will be created.",
                            "সামনে তাকানো একটা পরিষ্কার ছবি বাছুন। 4×6 ইঞ্চি প্রিন্ট শিট তৈরি হবে।"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = { TextButton(onClick = { c.idPhotoDialog = false }) { Text(tr("Cancel", "বাতিল")) } },
        )
    }
}
